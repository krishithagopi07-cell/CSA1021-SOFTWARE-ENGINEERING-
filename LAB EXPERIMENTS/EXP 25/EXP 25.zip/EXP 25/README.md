# Experiment 25: Creating a GitHub Repository and Pushing a README File

**Tools Used:** Git/GitHub  
**Course Outcome:** CO3

## Aim
To creating a GitHub Repository and Pushing a README File.

## Procedure
1. Create a new repo on GitHub
2. git init, add README.md
3. git remote add origin, git push -u origin main

## Deliverables Checklist
- [ ] Repo link
- [ ] README.md
- [ ] Commit screenshot

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

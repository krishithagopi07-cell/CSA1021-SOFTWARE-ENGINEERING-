# Experiment 30: Forking, Feature Branch and Pull Request to the Original Repository

**Tools Used:** Git/GitHub  
**Course Outcome:** CO4

## Aim
To forking, Feature Branch and Pull Request to the Original Repository.

## Procedure
1. Fork the upstream repo
2. Clone and add upstream remote
3. Create a feature branch, commit, push
4. Open a PR to the original repo

## Deliverables Checklist
- [ ] Fork link
- [ ] Feature branch name
- [ ] PR URL and screenshots

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

# Experiment 4: Flowchart to Find the Length of a String using RAPTOR

**Tools Used:** Raptor  
**Course Outcome:** CO1

## Aim
To flowchart to Find the Length of a String using RAPTOR.

## Procedure
1. Open RAPTOR and create a new flowchart
2. Input string, initialise count = 0
3. Loop through characters, increment count
4. Output count and run the flowchart

## Deliverables Checklist
- [ ] string_length.rap (save from RAPTOR)
- [ ] Flowchart screenshot
- [ ] sample-io.txt

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

# Experiment 29: Feature Branch (feature-login) and Pull Request

**Tools Used:** Git/GitHub  
**Course Outcome:** CO4

## Aim
To feature Branch (feature-login) and Pull Request.

## Procedure
1. git checkout -b feature-login
2. Add login.html, commit, push
3. Open a PR and merge it

## Deliverables Checklist
- [ ] feature-login branch
- [ ] PR URL
- [ ] Merged PR screenshot

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

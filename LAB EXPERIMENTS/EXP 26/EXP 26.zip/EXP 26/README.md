# Experiment 26: Cloning a GitHub Repository and Editing Files Locally

**Tools Used:** Git/GitHub  
**Course Outcome:** CO3

## Aim
To cloning a GitHub Repository and Editing Files Locally.

## Procedure
1. git clone <url>
2. Edit a file locally
3. git status and git diff

## Deliverables Checklist
- [ ] Clone output
- [ ] Edited file
- [ ] Before/after screenshots

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

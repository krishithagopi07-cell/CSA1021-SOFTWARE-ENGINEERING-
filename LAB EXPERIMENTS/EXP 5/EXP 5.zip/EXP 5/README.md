# Experiment 5: Lexicographically Smallest String by Swapping Two Characters using RAPTOR

**Tools Used:** Raptor  
**Course Outcome:** CO1

## Aim
To lexicographically Smallest String by Swapping Two Characters using RAPTOR.

## Procedure
1. Read the string
2. For each position i find the smallest later character smaller than s[i]
3. Swap with its last occurrence and stop
4. Output the string and run test cases

## Deliverables Checklist
- [ ] smallest_string.rap (save from RAPTOR)
- [ ] Flowchart screenshot
- [ ] test-cases.md

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

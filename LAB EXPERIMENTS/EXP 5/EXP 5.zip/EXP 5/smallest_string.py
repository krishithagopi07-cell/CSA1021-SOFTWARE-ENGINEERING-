def smallest_after_one_swap(s):
    s = list(s)
    n = len(s)
    for i in range(n - 1):
        m = min(s[i + 1:])
        if m < s[i]:
            j = n - 1 - s[::-1].index(m)   # last occurrence of m
            s[i], s[j] = s[j], s[i]
            break
    return "".join(s)

if __name__ == "__main__":
    print(smallest_after_one_swap(input("Enter string: ")))

| Input | Expected Output |
|-------|-----------------|
| dcba  | acbd |
| abc   | abc |
| bca   | acb |
| zyx   | xyz |
| a     | a |
| bbaa  | abab |

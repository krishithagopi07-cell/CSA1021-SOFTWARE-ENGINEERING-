# Experiment 28: Pulling Collaborator Changes from GitHub

**Tools Used:** Git/GitHub  
**Course Outcome:** CO4

## Aim
To pulling Collaborator Changes from GitHub.

## Procedure
1. Collaborator pushes a commit
2. git fetch and git pull
3. git log to verify

## Deliverables Checklist
- [ ] git pull output
- [ ] Collaborator commit screenshot
- [ ] git log

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

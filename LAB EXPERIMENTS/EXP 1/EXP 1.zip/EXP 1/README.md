# Experiment 1: Kanban Board for Task Visualization using Jira

**Tools Used:** Jira or Trello  
**Course Outcome:** CO1

## Aim
To kanban Board for Task Visualization using Jira.

## Procedure
1. Create a Jira/Trello project using the Kanban template
2. Add columns: To Do, In Progress, Review, Done
3. Create at least 8 tasks and assign them
4. Move tasks across columns and set WIP limits
5. Take screenshots and export issues to CSV

## Deliverables Checklist
- [ ] Board screenshots (before/after moving tasks)
- [ ] Board link in board-link.txt
- [ ] kanban-board-export.csv

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

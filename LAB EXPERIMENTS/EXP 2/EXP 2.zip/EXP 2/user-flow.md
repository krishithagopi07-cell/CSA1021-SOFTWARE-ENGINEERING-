# User Flow
```mermaid
flowchart LR
  A[Splash] --> B[Login/Register] --> C[Search Route & Date]
  C --> D[Bus List] --> E[Seat Selection] --> F[Passenger Details]
  F --> G[Payment] --> H[E-Ticket]
```

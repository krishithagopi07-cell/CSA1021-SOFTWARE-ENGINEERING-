# Experiment 2: Prototype of a Bus Ticket Booking System using Figma

**Tools Used:** Figma  
**Course Outcome:** CO1

## Aim
To prototype of a Bus Ticket Booking System using Figma.

## Procedure
1. Identify screens: Splash, Login, Search, Seat Selection, Payment, Ticket
2. Design frames in Figma
3. Link frames using Prototype mode
4. Present and test the flow

## Deliverables Checklist
- [ ] Exported frames (PDF/PNG)
- [ ] Prototype link in figma-links.md
- [ ] user-flow.md

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

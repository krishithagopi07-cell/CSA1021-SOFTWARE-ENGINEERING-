import { useEffect, useMemo, useState } from "react";

type IconName =
  | "bus" | "map" | "calendar" | "users" | "swap" | "search" | "clock"
  | "wifi" | "plug" | "snow" | "chevron" | "shield" | "ticket" | "arrow"
  | "close" | "seat" | "filter" | "support" | "route" | "user" | "logout"
  | "download" | "card" | "check" | "back" | "eye" | "plus";

const paths: Record<IconName, React.ReactNode> = {
  bus: <><path d="M6 17h12M6 4h12a2 2 0 0 1 2 2v9H4V6a2 2 0 0 1 2-2Z"/><path d="M4 10h16M8 19v1M16 19v1M7 15v2M17 15v2"/></>,
  map: <><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z"/><path d="M9 3v15M15 6v15"/></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
  users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></>,
  swap: <><path d="m7 16-4-4 4-4M3 12h18M17 8l4 4-4 4"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  wifi: <><path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19" r=".8" fill="currentColor"/></>,
  plug: <><path d="M9 2v6M15 2v6M7 8h10v2a5 5 0 0 1-10 0Z"/><path d="M12 15v7"/></>,
  snow: <><path d="M12 2v20M4.3 6.5l15.4 11M19.7 6.5l-15.4 11M9 4l3 3 3-3M9 20l3-3 3 3"/></>,
  chevron: <path d="m9 18 6-6-6-6"/>,
  shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></>,
  ticket: <><path d="M3 9a3 3 0 0 0 0 6v3h18v-3a3 3 0 0 0 0-6V6H3Z"/><path d="M13 6v12"/></>,
  arrow: <><path d="M5 12h14M14 7l5 5-5 5"/></>,
  close: <><path d="m6 6 12 12M18 6 6 18"/></>,
  seat: <><path d="M6 11V5a3 3 0 0 1 6 0v6M6 9H4a2 2 0 0 0-2 2v4h13v-4a2 2 0 0 0-2-2h-1M4 15v4M13 15v4"/></>,
  filter: <path d="M4 6h16M7 12h10M10 18h4"/>,
  support: <><circle cx="12" cy="12" r="9"/><path d="M7 14v-3a5 5 0 0 1 10 0v3M7 14h2v4H7a2 2 0 0 1-2-2M17 14h2v2a2 2 0 0 1-2 2Z"/></>,
  route: <><circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h3a3 3 0 0 0 3-3v-6a3 3 0 0 1 3-3"/></>,
  user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
  logout: <><path d="M10 17l5-5-5-5M15 12H3M15 3h5v18h-5"/></>,
  download: <><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></>,
  card: <><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  back: <><path d="m15 18-6-6 6-6"/></>,
  eye: <><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></>,
  plus: <><path d="M12 5v14M5 12h14"/></>,
};

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

type Passenger = { name: string; age: string; gender: string; contact: string };
type Trip = typeof trips[number];
type Booking = {
  id: string; transactionId: string; user: string; createdAt: string; bus: string; busType: string;
  from: string; to: string; journeyDate: string; departure: string; arrival: string;
  passengers: (Passenger & { seat: string })[]; fare: number; paymentMethod: string; status: "Confirmed";
};

const trips = [
  { id: 1, company: "Northline", initials: "N", type: "Premium Sleeper", depart: "07:30", arrive: "12:15", duration: "4h 45m", price: 38, rating: "4.9", reviews: 312, seats: 8, tone: "navy", tags: ["wifi", "plug", "snow"] as IconName[] },
  { id: 2, company: "Aurora Coach", initials: "A", type: "Business Class", depart: "09:15", arrive: "13:40", duration: "4h 25m", price: 42, rating: "4.8", reviews: 248, seats: 5, tone: "gold", tags: ["wifi", "plug", "snow"] as IconName[] },
  { id: 3, company: "Greenway", initials: "G", type: "Express", depart: "12:20", arrive: "17:30", duration: "5h 10m", price: 29, rating: "4.7", reviews: 186, seats: 14, tone: "green", tags: ["wifi", "plug"] as IconName[] },
];

const emptyPassenger = (): Passenger => ({ name: "", age: "", gender: "", contact: "" });
const allSeats = ["1A","1B","1C","1D","2A","2B","2C","2D","3A","3B","3C","3D","4A","4B","4C","4D","5A","5B","5C","5D"];
const takenSeats = ["1B", "1C", "2D", "3C", "4D"];

function createPdf(title: string, lines: string[], filename: string) {
  const safe = (value: string) => value.replace(/[^\x20-\x7E]/g, "-").replace(/([\\()])/g, "\\$1");
  const text = [`BT /F1 18 Tf 54 770 Td (${safe(title)}) Tj`, ...lines.map((line, index) => `0 -${index === 0 ? 32 : 20} Td /F1 11 Tf (${safe(line)}) Tj`), "ET"].join("\n");
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
    `<< /Length ${text.length} >>\nstream\n${text}\nendstream`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => { offsets.push(pdf.length); pdf += `${index + 1} 0 obj\n${object}\nendobj\n`; });
  const xref = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach((offset) => { pdf += `${String(offset).padStart(10, "0")} 00000 n \n`; });
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  const url = URL.createObjectURL(new Blob([pdf], { type: "application/pdf" }));
  const link = document.createElement("a");
  link.href = url; link.download = filename; link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function AuthScreen({ onAuthenticated }: { onAuthenticated: (email: string) => void }) {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  function submit(event: React.FormEvent) {
    event.preventDefault();
    const cleanEmail = email.trim();
    if (!cleanEmail || !(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail) || /^\+?[\d\s-]{8,}$/.test(cleanEmail))) {
      setError("Enter a valid email address or phone number."); return;
    }
    if (password.length < 6) { setError("Password must contain at least 6 characters."); return; }
    if (mode === "signup" && name.trim().length < 2) { setError("Please enter your full name."); return; }
    localStorage.setItem("busgo-user", JSON.stringify({ email: cleanEmail, name: name.trim() || cleanEmail.split("@")[0] }));
    onAuthenticated(cleanEmail);
  }

  return (
    <main className="auth-page">
      <section className="auth-story">
        <div className="auth-brand"><span className="brand-mark"><Icon name="bus" size={22}/></span><strong>BusGo</strong></div>
        <div className="auth-copy"><span className="auth-eyebrow">Travel made effortless</span><h1>Every journey starts<br/>with a simple choice.</h1><p>Compare trusted operators, choose your seat, and travel with confidence.</p></div>
        <div className="auth-proof"><span><Icon name="shield"/>Secure booking</span><span><Icon name="support"/>24/7 support</span></div>
      </section>
      <section className="auth-panel">
        <form className="auth-form" onSubmit={submit}>
          <div className="auth-form-head"><span>Welcome to BusGo</span><h2>{mode === "signin" ? "Sign in to continue" : "Create your account"}</h2><p>{mode === "signin" ? "Your next journey is just a few clicks away." : "Save trips and manage every booking in one place."}</p></div>
          {mode === "signup" && <label>Full name<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Alex Morgan" autoComplete="name"/></label>}
          <label>Email or phone number<input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="username"/></label>
          <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" autoComplete={mode === "signin" ? "current-password" : "new-password"}/></label>
          {error && <div className="form-error">{error}</div>}
          <button className="primary-action" type="submit">{mode === "signin" ? "Sign in" : "Create account"}<Icon name="arrow"/></button>
          <p className="auth-switch">{mode === "signin" ? "New to BusGo?" : "Already have an account?"}<button type="button" onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(""); }}>{mode === "signin" ? "Create account" : "Sign in"}</button></p>
          <small className="prototype-note"><Icon name="shield" size={14}/>Prototype authentication · Do not use a real password</small>
        </form>
      </section>
    </main>
  );
}

function App() {
  const savedUser = localStorage.getItem("busgo-user");
  const [user, setUser] = useState<string>(() => savedUser ? JSON.parse(savedUser).email : "");
  const [page, setPage] = useState<"dashboard" | "trips">("dashboard");
  const [from, setFrom] = useState("New York");
  const [to, setTo] = useState("Boston");
  const [date, setDate] = useState("2026-06-18");
  const [passengerCount, setPassengerCount] = useState(1);
  const [sort, setSort] = useState("Recommended");
  const [timeFilter, setTimeFilter] = useState("Any time");
  const [featureFilters, setFeatureFilters] = useState<string[]>([]);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [checkoutStep, setCheckoutStep] = useState<"seats" | "details" | "payment" | "confirmed">("seats");
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [passengers, setPassengers] = useState<Passenger[]>([emptyPassenger()]);
  const [detailErrors, setDetailErrors] = useState<string[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<"card" | "upi" | "wallet">("card");
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [upiId, setUpiId] = useState("");
  const [paymentState, setPaymentState] = useState<"idle" | "processing" | "failed">("idle");
  const [paymentError, setPaymentError] = useState("");
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const [activeBooking, setActiveBooking] = useState<Booking | null>(null);
  const [toast, setToast] = useState("");
  const [bookings, setBookings] = useState<Booking[]>(() => JSON.parse(localStorage.getItem("busgo-bookings") || "[]"));

  useEffect(() => {
    setPassengers((current) => Array.from({ length: passengerCount }, (_, index) => current[index] || emptyPassenger()));
    setSelectedSeats((current) => current.slice(0, passengerCount));
  }, [passengerCount]);

  const sortedTrips = useMemo(() => {
    const featureMap: Record<string, IconName> = { "Wi-Fi": "wifi", "Power outlets": "plug", "Extra legroom": "seat" };
    const filtered = trips.filter((trip) => {
      const hour = Number(trip.depart.split(":")[0]);
      const matchesTime = timeFilter === "Any time" || (timeFilter === "Morning" && hour < 12) || (timeFilter === "Afternoon" && hour >= 12 && hour < 18) || (timeFilter === "Evening" && hour >= 18);
      return matchesTime && featureFilters.every((feature) => trip.tags.includes(featureMap[feature]));
    });
    if (sort === "Lowest price") return [...filtered].sort((a, b) => a.price - b.price);
    if (sort === "Fastest") return [...filtered].sort((a, b) => a.duration.localeCompare(b.duration));
    return filtered;
  }, [sort, timeFilter, featureFilters]);
  const userBookings = bookings.filter((booking) => booking.user === user);

  if (!user) return <AuthScreen onAuthenticated={(email) => { setUser(email); setPage("dashboard"); }}/>;

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2800);
  }

  function logout() {
    localStorage.removeItem("busgo-user");
    setUser("");
    setSelectedTrip(null);
  }

  function runSearch(event: React.FormEvent) {
    event.preventDefault();
    if (!from.trim() || !to.trim()) { showToast("Add both departure and destination cities"); return; }
    if (from.trim().toLowerCase() === to.trim().toLowerCase()) { showToast("Departure and destination must be different"); return; }
    document.getElementById("results")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function startCheckout(trip: Trip) {
    if (passengerCount > trip.seats) { showToast(`Only ${trip.seats} seats remain on this bus`); return; }
    setSelectedTrip(trip); setSelectedSeats([]); setCheckoutStep("seats"); setPaymentState("idle"); setConfirmedBooking(null);
  }

  function toggleSeat(seat: string) {
    setSelectedSeats((current) => current.includes(seat) ? current.filter((item) => item !== seat) : current.length < passengerCount ? [...current, seat] : current);
  }

  function validateDetails() {
    const errors = passengers.map((passenger) => {
      if (passenger.name.trim().length < 2) return "Enter the passenger's full name.";
      if (!passenger.age || Number(passenger.age) < 1 || Number(passenger.age) > 110) return "Enter a valid age.";
      if (!passenger.gender) return "Select a gender.";
      if (!/^[\w.+-]+@[\w.-]+\.\w+$/.test(passenger.contact) && !/^\+?[\d\s-]{8,}$/.test(passenger.contact)) return "Enter a valid email or phone number.";
      return "";
    });
    setDetailErrors(errors);
    if (!errors.some(Boolean)) setCheckoutStep("payment");
  }

  function completePayment() {
    if (!selectedTrip) return;
    setPaymentError("");
    if (paymentMethod === "card" && (cardNumber.replace(/\s/g, "").length < 12 || !/^\d{2}\/\d{2}$/.test(cardExpiry) || !/^\d{3,4}$/.test(cardCvv))) { setPaymentError("Enter a valid sandbox card number, MM/YY expiry, and CVV."); return; }
    if (paymentMethod === "upi" && !/^[\w.-]+@[\w.-]+$/.test(upiId)) { setPaymentError("Enter a valid UPI ID, for example name@bank."); return; }
    setPaymentState("processing");
    window.setTimeout(() => {
      if ((paymentMethod === "card" && cardNumber.replace(/\s/g, "").endsWith("0000")) || (paymentMethod === "upi" && upiId.startsWith("fail"))) {
        setPaymentState("failed"); setPaymentError("Test payment was declined. Check the details and retry."); return;
      }
      const booking: Booking = {
        id: `BG${Date.now().toString().slice(-8)}`, transactionId: `TXN${Math.random().toString(36).slice(2, 10).toUpperCase()}`,
        user, createdAt: new Date().toISOString(), bus: selectedTrip.company, busType: selectedTrip.type, from, to,
        journeyDate: date, departure: selectedTrip.depart, arrival: selectedTrip.arrive,
        passengers: passengers.map((passenger, index) => ({ ...passenger, seat: selectedSeats[index] })),
        fare: selectedTrip.price * passengerCount, paymentMethod, status: "Confirmed",
      };
      const updated = [booking, ...bookings];
      localStorage.setItem("busgo-bookings", JSON.stringify(updated));
      setBookings(updated); setConfirmedBooking(booking); setCheckoutStep("confirmed"); setPaymentState("idle");
    }, 1100);
  }

  function documentLines(booking: Booking, receipt = false) {
    const common = [
      `Booking ID: ${booking.id}`, `Status: ${booking.status}`, `Bus: ${booking.bus} - ${booking.busType}`,
      `Route: ${booking.from} to ${booking.to}`, `Journey: ${booking.journeyDate} at ${booking.depart}`,
      ...booking.passengers.map((p, i) => `Passenger ${i + 1}: ${p.name}, Age ${p.age}, ${p.gender}, Seat ${p.seat}`),
    ];
    return receipt ? [...common, `Payment: PAID via ${booking.paymentMethod.toUpperCase()}`, `Transaction: ${booking.transactionId}`, `Total paid: $${booking.fare}.00`] : [...common, `Total fare: $${booking.fare}.00`, `Payment status: PAID`, "Please arrive at least 15 minutes before departure."];
  }

  function downloadTicket(booking: Booking) { createPdf("BusGo Electronic Ticket", documentLines(booking), `BusGo-ticket-${booking.id}.pdf`); }
  function downloadReceipt(booking: Booking) { createPdf("BusGo Payment Receipt", documentLines(booking, true), `BusGo-receipt-${booking.id}.pdf`); }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="nav-wrap">
          <button className="brand" onClick={() => { setPage("dashboard"); window.scrollTo({ top: 0, behavior: "smooth" }); }}><span className="brand-mark"><Icon name="bus" size={22}/></span><span>BusGo</span></button>
          <nav className="nav-links">
            <button className={page === "dashboard" ? "nav-active" : ""} onClick={() => setPage("dashboard")}>Book a trip</button>
            <button className={page === "trips" ? "nav-active" : ""} onClick={() => setPage("trips")}>My trips {userBookings.length > 0 && <span className="nav-count">{userBookings.length}</span>}</button>
            <button onClick={() => showToast("Support is available 24/7 at help@busgo.test")}>Help</button>
          </nav>
          <div className="nav-actions">
            <span className="signed-user"><Icon name="user" size={16}/>{user}</span>
            <button className="signin" onClick={logout}><Icon name="logout" size={15}/>Logout</button>
          </div>
        </div>
      </header>

      {page === "dashboard" ? (
        <main>
          <section className="hero">
            <div className="hero-photo"/><div className="hero-overlay"/>
            <div className="hero-content"><div className="eyebrow"><span/> Move freely, arrive refreshed</div><h1>Your next city is<br/><em>closer than you think.</em></h1><p>Comfortable intercity travel, thoughtfully made simple.</p></div>
          </section>
          <form className="search-card" onSubmit={runSearch}>
            <div className="field-group"><label htmlFor="from">From</label><div className="field-control"><Icon name="map"/><input id="from" value={from} onChange={(e) => setFrom(e.target.value)}/></div></div>
            <button type="button" className="swap" onClick={() => { setFrom(to); setTo(from); }}><Icon name="swap" size={17}/></button>
            <div className="field-group"><label htmlFor="to">To</label><div className="field-control"><Icon name="map"/><input id="to" value={to} onChange={(e) => setTo(e.target.value)}/></div></div>
            <div className="divider"/>
            <div className="field-group date-field"><label htmlFor="date">Departure</label><div className="field-control"><Icon name="calendar"/><input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)}/></div></div>
            <div className="divider"/>
            <div className="field-group passenger-field"><label htmlFor="passengers">Passengers</label><div className="field-control"><Icon name="users"/><select id="passengers" value={passengerCount} onChange={(e) => setPassengerCount(Number(e.target.value))}>{Array.from({ length: Math.max(...trips.map((trip) => trip.seats)) }, (_, i) => <option value={i + 1} key={i + 1}>{i + 1} passenger{i ? "s" : ""}</option>)}</select></div></div>
            <button className="search-button" type="submit"><Icon name="search"/>Search buses</button>
          </form>

          <section className="benefits">
            <div><span className="benefit-icon"><Icon name="shield"/></span><p><strong>Book with confidence</strong><small>Secure test payments, always</small></p></div>
            <div><span className="benefit-icon"><Icon name="ticket"/></span><p><strong>Instant e-tickets</strong><small>PDF ticket and receipt</small></p></div>
            <div><span className="benefit-icon"><Icon name="support"/></span><p><strong>Here when you need us</strong><small>Real help, around the clock</small></p></div>
          </section>

          <section className="results-section" id="results">
            <div className="results-heading">
              <div><div className="route-kicker"><Icon name="route" size={16}/> {from} to {to}</div><h2>Choose your ride</h2><p>{new Date(`${date}T12:00:00`).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })} · 3 buses available</p></div>
              <div className="date-switcher">
                <button onClick={() => setDate(new Date(new Date(`${date}T12:00:00`).getTime() - 86400000).toISOString().slice(0, 10))}>‹</button>
                {[-1, 0, 1, 2].map((offset) => {
                  const option = new Date(new Date(`${date}T12:00:00`).getTime() + offset * 86400000);
                  const value = option.toISOString().slice(0, 10);
                  return <button className={offset === 0 ? "selected" : ""} key={value} onClick={() => setDate(value)}><small>{option.toLocaleDateString("en-US", { weekday: "short" })}</small><strong>{option.getDate()}</strong></button>;
                })}
                <button onClick={() => setDate(new Date(new Date(`${date}T12:00:00`).getTime() + 86400000).toISOString().slice(0, 10))}>›</button>
              </div>
            </div>
            <div className="results-layout">
              <aside className="filters">
                <div className="filter-title"><span><Icon name="filter"/> Filters</span><button onClick={() => { setTimeFilter("Any time"); setFeatureFilters([]); }}>Reset</button></div>
                <fieldset><legend>Departure time</legend>{["Any time", "Morning", "Afternoon", "Evening"].map((label, i) => <label className="radio-row" key={label}><input type="radio" name="time" checked={timeFilter === label} onChange={() => setTimeFilter(label)}/><span>{label}<small>{i === 0 ? "3 trips" : i === 1 ? "06:00 – 11:59" : i === 2 ? "12:00 – 17:59" : "After 18:00"}</small></span></label>)}</fieldset>
                <fieldset><legend>Bus features</legend>{["Wi-Fi", "Power outlets", "Extra legroom"].map((label) => <label className="check-row" key={label}><input type="checkbox" checked={featureFilters.includes(label)} onChange={() => setFeatureFilters((current) => current.includes(label) ? current.filter((item) => item !== label) : [...current, label])}/><span>{label}</span></label>)}</fieldset>
              </aside>
              <div className="trip-list">
                <div className="list-tools"><span>Best options for {passengerCount} passenger{passengerCount > 1 ? "s" : ""}</span><label>Sort by <select value={sort} onChange={(e) => setSort(e.target.value)}><option>Recommended</option><option>Lowest price</option><option>Fastest</option></select></label></div>
                {sortedTrips.map((trip, index) => (
                  <article className="trip-card" key={trip.id}>
                    {index === 0 && sort === "Recommended" && <div className="best-tag">Best choice</div>}
                    <div className="operator"><span className={`operator-logo ${trip.tone}`}>{trip.initials}</span><div><strong>{trip.company}</strong><small>{trip.type}</small></div></div>
                    <div className="timeline"><div><strong>{trip.depart}</strong><small>{from}</small></div><div className="journey"><small><Icon name="clock" size={13}/>{trip.duration}</small><span><i/><b/><i/></span><small>Direct</small></div><div><strong>{trip.arrive}</strong><small>{to}</small></div></div>
                    <div className="amenities"><span className="rating">★ {trip.rating}</span><small>{trip.reviews} reviews</small><div>{trip.tags.map((tag) => <span title={tag} key={tag}><Icon name={tag} size={16}/></span>)}</div></div>
                    <div className="price-block"><small>{passengerCount > 1 ? `${passengerCount} tickets` : "from"}</small><strong>${trip.price * passengerCount}<sup>.00</sup></strong><span>{trip.seats} seats left</span><button onClick={() => startCheckout(trip)} disabled={passengerCount > trip.seats}>Select seats <Icon name="arrow" size={16}/></button></div>
                  </article>
                ))}
                {sortedTrips.length === 0 && <div className="no-results"><Icon name="search" size={26}/><strong>No matching buses</strong><span>Adjust your filters to see more departures.</span><button onClick={() => { setTimeFilter("Any time"); setFeatureFilters([]); }}>Clear filters</button></div>}
              </div>
            </div>
          </section>
        </main>
      ) : (
        <main className="trips-page">
          <div className="page-heading"><span className="route-kicker"><Icon name="ticket"/> Your journeys</span><h1>My trips</h1><p>View confirmed bookings and download your travel documents.</p></div>
          {userBookings.length === 0 ? (
            <section className="empty-trips"><span><Icon name="ticket" size={32}/></span><h2>No trips booked yet</h2><p>When you complete a booking, it will appear here automatically.</p><button className="primary-action" onClick={() => setPage("dashboard")}>Find a bus <Icon name="arrow"/></button></section>
          ) : (
            <section className="booking-list">
              {userBookings.map((booking) => <article className="booking-card" key={booking.id}>
                <div className="booking-status"><span><Icon name="check" size={14}/>Confirmed</span><small>Booking ID {booking.id}</small></div>
                <div className="booking-route"><span className="operator-logo">{booking.bus[0]}</span><div><small>{booking.bus} · {booking.busType}</small><h2>{booking.from} <Icon name="arrow" size={18}/> {booking.to}</h2><p>{new Date(`${booking.journeyDate}T12:00:00`).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" })} · {booking.depart} · {booking.passengers.length} passenger{booking.passengers.length > 1 ? "s" : ""}</p></div></div>
                <div className="booking-seats"><small>Seats</small><strong>{booking.passengers.map((p) => p.seat).join(", ")}</strong></div>
                <div className="booking-actions"><button onClick={() => setActiveBooking(booking)}><Icon name="eye" size={15}/>View details</button><button onClick={() => downloadTicket(booking)}><Icon name="download" size={15}/>Ticket</button></div>
              </article>)}
            </section>
          )}
        </main>
      )}

      <footer><div className="footer-inner"><div className="footer-brand"><span className="brand-mark"><Icon name="bus" size={20}/></span><strong>BusGo</strong><small>Better journeys, from door to door.</small></div><span>© 2026 BusGo Inc.</span><div><button onClick={() => showToast("Terms are available in this prototype")}>Terms</button><button onClick={() => showToast("Your bookings stay in this browser only")}>Privacy</button><button onClick={() => showToast("BusGo supports keyboard navigation")}>Accessibility</button></div></div></footer>

      {selectedTrip && (
        <div className="modal-backdrop">
          <section className="booking-modal" role="dialog" aria-modal="true">
            <button className="modal-close" onClick={() => setSelectedTrip(null)}><Icon name="close"/></button>
            <div className="checkout-header">
              <div><span className={`operator-logo ${selectedTrip.tone}`}>{selectedTrip.initials}</span><p><small>{selectedTrip.company} · {selectedTrip.depart}</small><strong>{checkoutStep === "seats" ? "Choose your seats" : checkoutStep === "details" ? "Passenger details" : checkoutStep === "payment" ? "Secure payment" : "Booking confirmed"}</strong></p></div>
              <div className="stepper">{["seats", "details", "payment", "confirmed"].map((step, index) => <span className={checkoutStep === step || ["seats", "details", "payment", "confirmed"].indexOf(checkoutStep) > index ? "done" : ""} key={step}><i>{index < ["seats", "details", "payment", "confirmed"].indexOf(checkoutStep) ? "✓" : index + 1}</i>{index < 3 && <b/>}</span>)}</div>
            </div>

            {checkoutStep === "seats" && <div className="checkout-grid">
              <div className="coach">
                <div className="selection-intro"><h3>Select {passengerCount} seat{passengerCount > 1 ? "s" : ""}</h3><p>{selectedSeats.length} of {passengerCount} selected</p></div>
                <div className="coach-top"><span>Front of bus</span><span className="wheel">◯</span></div>
                <div className="seat-grid">{allSeats.map((seat) => <button key={seat} disabled={takenSeats.includes(seat)} className={selectedSeats.includes(seat) ? "seat selected-seat" : "seat"} onClick={() => toggleSeat(seat)}><Icon name="seat" size={19}/><span>{seat}</span></button>)}</div>
                <div className="seat-legend"><span><i/>Available</span><span><i className="chosen"/>Selected</span><span><i className="taken"/>Taken</span></div>
              </div>
              <CheckoutSummary trip={selectedTrip} count={passengerCount} seats={selectedSeats} from={from} to={to} date={date} onContinue={() => setCheckoutStep("details")} disabled={selectedSeats.length !== passengerCount}/>
            </div>}

            {checkoutStep === "details" && <div className="checkout-grid">
              <div className="passenger-forms">
                <div className="selection-intro"><h3>Who's travelling?</h3><p>Enter details exactly as shown on identification.</p></div>
                {passengers.map((passenger, index) => <div className="passenger-form" key={index}>
                  <div className="passenger-form-title"><span>{index + 1}</span><strong>Passenger {index + 1}</strong><small>Seat {selectedSeats[index]}</small></div>
                  <label className="wide">Full name<input value={passenger.name} onChange={(e) => setPassengers(passengers.map((p, i) => i === index ? { ...p, name: e.target.value } : p))} placeholder="Full legal name"/></label>
                  <label>Age<input type="number" min="1" max="110" value={passenger.age} onChange={(e) => setPassengers(passengers.map((p, i) => i === index ? { ...p, age: e.target.value } : p))} placeholder="Age"/></label>
                  <label>Gender<select value={passenger.gender} onChange={(e) => setPassengers(passengers.map((p, i) => i === index ? { ...p, gender: e.target.value } : p))}><option value="">Select</option><option>Female</option><option>Male</option><option>Non-binary</option><option>Prefer not to say</option></select></label>
                  <label className="wide">Email or phone<input value={passenger.contact} onChange={(e) => setPassengers(passengers.map((p, i) => i === index ? { ...p, contact: e.target.value } : p))} placeholder="For ticket updates"/></label>
                  {detailErrors[index] && <div className="inline-error">{detailErrors[index]}</div>}
                </div>)}
              </div>
              <CheckoutSummary trip={selectedTrip} count={passengerCount} seats={selectedSeats} from={from} to={to} date={date} onContinue={validateDetails} onBack={() => setCheckoutStep("seats")}/>
            </div>}

            {checkoutStep === "payment" && <div className="checkout-grid">
              <div className="payment-panel">
                <div className="sandbox-banner"><Icon name="shield"/><div><strong>Test payment environment</strong><span>No real money will be charged. Successful payments are simulated and clearly recorded as test transactions.</span></div></div>
                <div className="selection-intro"><h3>Choose payment method</h3><p>Your booking is confirmed only after test payment verification.</p></div>
                <div className="payment-methods">
                  <button className={paymentMethod === "card" ? "active" : ""} onClick={() => setPaymentMethod("card")}><Icon name="card"/>Card</button>
                  <button className={paymentMethod === "upi" ? "active" : ""} onClick={() => setPaymentMethod("upi")}><strong>UPI</strong>UPI</button>
                  <button className={paymentMethod === "wallet" ? "active" : ""} onClick={() => setPaymentMethod("wallet")}><Icon name="ticket"/>Test wallet</button>
                </div>
                {paymentMethod === "card" && <div className="payment-fields"><label>Card number<input value={cardNumber} onChange={(e) => setCardNumber(e.target.value.replace(/[^\d\s]/g, ""))} placeholder="4242 4242 4242 4242" maxLength={19}/></label><div><label>Expiry<input value={cardExpiry} onChange={(e) => setCardExpiry(e.target.value.replace(/[^\d/]/g, "").slice(0, 5))} placeholder="12/30"/></label><label>CVV<input type="password" value={cardCvv} onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ""))} placeholder="123" maxLength={4}/></label></div><small>Use any 12+ digits. A number ending in 0000 triggers a test decline.</small></div>}
                {paymentMethod === "upi" && <div className="payment-fields"><label>UPI ID<input value={upiId} onChange={(e) => setUpiId(e.target.value)} placeholder="name@bank"/></label><small>Use an ID starting with “fail” to test a declined payment.</small></div>}
                {paymentMethod === "wallet" && <div className="wallet-box"><span><Icon name="check"/></span><p><strong>BusGo test wallet</strong><small>Sandbox balance: $500.00</small></p></div>}
                {(paymentError || paymentState === "failed") && <div className="payment-error">{paymentError}<button onClick={() => { setPaymentState("idle"); setPaymentError(""); }}>Retry payment</button></div>}
              </div>
              <aside className="summary payment-summary">
                <p className="summary-label">Order summary</p><h3>{from} <Icon name="arrow" size={17}/> {to}</h3><p>{date} · {selectedTrip.depart}</p>
                {passengers.map((p, i) => <div className="summary-line" key={i}><span>{p.name} · Seat {selectedSeats[i]}</span><strong>${selectedTrip.price}.00</strong></div>)}
                <div className="summary-total"><span>Total</span><strong>${selectedTrip.price * passengerCount}.00</strong></div>
                <button className="continue-button" disabled={paymentState === "processing"} onClick={completePayment}>{paymentState === "processing" ? "Verifying test payment…" : `Pay $${selectedTrip.price * passengerCount}.00`}<Icon name="shield" size={16}/></button>
                <button className="back-link" onClick={() => setCheckoutStep("details")}><Icon name="back" size={14}/>Back to passenger details</button>
                <button className="cancel-link" onClick={() => { setSelectedTrip(null); showToast("Test payment cancelled. No booking was created."); }}>Cancel payment</button>
              </aside>
            </div>}

            {checkoutStep === "confirmed" && confirmedBooking && <Confirmation booking={confirmedBooking} onTicket={() => downloadTicket(confirmedBooking)} onReceipt={() => downloadReceipt(confirmedBooking)} onTrips={() => { setSelectedTrip(null); setPage("trips"); }}/>}
          </section>
        </div>
      )}

      {activeBooking && <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setActiveBooking(null); }}><section className="detail-modal"><button className="modal-close" onClick={() => setActiveBooking(null)}><Icon name="close"/></button><Confirmation booking={activeBooking} compact onTicket={() => downloadTicket(activeBooking)} onReceipt={() => downloadReceipt(activeBooking)} onTrips={() => setActiveBooking(null)}/></section></div>}
      {toast && <div className="toast"><Icon name="shield" size={17}/>{toast}</div>}
    </div>
  );
}

function CheckoutSummary({ trip, count, seats, from, to, date, onContinue, onBack, disabled }: { trip: Trip; count: number; seats: string[]; from: string; to: string; date: string; onContinue: () => void; onBack?: () => void; disabled?: boolean }) {
  return <aside className="summary"><p className="summary-label">Your trip</p><h3>{from} <Icon name="arrow" size={17}/> {to}</h3><p>{date} · {trip.depart}</p><div className="summary-line"><span>{count} passenger{count > 1 ? "s" : ""}</span><strong>${trip.price * count}.00</strong></div><div className="summary-line"><span>Seats</span><strong>{seats.join(", ") || "Not selected"}</strong></div><div className="summary-total"><span>Total</span><strong>${trip.price * count}.00</strong></div><button className="continue-button" disabled={disabled} onClick={onContinue}>Continue <Icon name="arrow" size={17}/></button>{onBack && <button className="back-link" onClick={onBack}><Icon name="back" size={14}/>Back to seats</button>}<small className="secure-note"><Icon name="shield" size={15}/>No booking fees · Secure checkout</small></aside>;
}

function Confirmation({ booking, onTicket, onReceipt, onTrips, compact = false }: { booking: Booking; onTicket: () => void; onReceipt: () => void; onTrips: () => void; compact?: boolean }) {
  return <div className={compact ? "confirmation compact-confirmation" : "confirmation"}><span className="confirmation-icon"><Icon name="check" size={32}/></span><p className="summary-label">{compact ? "Booking details" : "Payment verified"}</p><h2>{compact ? booking.id : "Your booking is confirmed"}</h2><p>{compact ? "Your confirmed itinerary and passenger information." : `A test payment receipt and tickets are ready. Booking ID ${booking.id}`}</p><div className="ticket-preview"><div><span className="operator-logo">{booking.bus[0]}</span><p><small>{booking.bus} · {booking.busType}</small><strong>{booking.from} <Icon name="arrow" size={16}/> {booking.to}</strong><span>{booking.journeyDate} · {booking.depart}–{booking.arrival}</span></p></div><div className="ticket-passengers">{booking.passengers.map((passenger) => <span key={passenger.seat}><strong>{passenger.name}</strong><small>Seat {passenger.seat} · Age {passenger.age} · {passenger.gender}</small></span>)}</div><div className="ticket-total"><span><small>Payment status</small><strong>PAID · TEST</strong></span><span><small>Transaction</small><strong>{booking.transactionId}</strong></span><span><small>Total fare</small><strong>${booking.fare}.00</strong></span></div></div><div className="confirmation-actions"><button onClick={onTicket}><Icon name="download"/>Download ticket</button><button onClick={onReceipt}><Icon name="download"/>Download receipt</button><button className="primary-action" onClick={onTrips}>{compact ? "Close details" : "View My Trips"}<Icon name="arrow"/></button></div></div>;
}

export default App;

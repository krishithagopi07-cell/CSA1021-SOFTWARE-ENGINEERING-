# Experiment 27: Committing and Pushing Changes to GitHub

**Tools Used:** Git/GitHub  
**Course Outcome:** CO4

## Aim
To committing and Pushing Changes to GitHub.

## Procedure
1. git add .
2. git commit -m message
3. git push origin main
4. View commit history on GitHub

## Deliverables Checklist
- [ ] commands.log
- [ ] Commit history screenshot

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

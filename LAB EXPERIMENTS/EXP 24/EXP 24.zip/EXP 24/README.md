# Experiment 24: CI/CD Pipeline for a Flask Application using GitHub Actions with Cloud Deployment

**Tools Used:** GitHub Actions, Docker  
**Course Outcome:** CO3

## Aim
To cI/CD Pipeline for a Flask Application using GitHub Actions with Cloud Deployment.

## Procedure
1. Write tests with pytest
2. Create the workflow: test, build, push, deploy
3. Add secrets for Docker Hub and the cloud provider
4. Verify the deployed URL

## Deliverables Checklist
- [ ] ci-cd.yml, Dockerfile, tests
- [ ] Deployed cloud URL
- [ ] Actions screenshot

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

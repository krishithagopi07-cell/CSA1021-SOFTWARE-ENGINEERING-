# Stakeholder Feedback

| # | Stakeholder | Feedback | Action Taken | Status |
|---|-------------|----------|--------------|--------|
| 1 | Customer | Checkout has too many steps | Merged address and payment | Done |
| 2 | Product Owner | Add wishlist | Added heart icon | Done |
| 3 | Developer | Need consistent spacing | Applied 8px grid | Done |

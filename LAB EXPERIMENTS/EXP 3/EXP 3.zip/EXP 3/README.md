# Experiment 3: E-Commerce Mobile App Prototype using Figma for Stakeholder Feedback

**Tools Used:** Figma  
**Course Outcome:** CO1

## Aim
To e-Commerce Mobile App Prototype using Figma for Stakeholder Feedback.

## Procedure
1. Design screens: Home, Product List, Product Detail, Cart, Checkout
2. Create interactive prototype
3. Share the link with stakeholders and collect feedback
4. Revise the design based on feedback

## Deliverables Checklist
- [ ] Exported frames (PDF/PNG)
- [ ] Prototype link in figma-links.md
- [ ] stakeholder-feedback.md

## Output / Screenshots
See the `screenshots/` folder.

| # | File | Description |
|---|------|-------------|
| 1 | screenshots/01-... | |

## Result
The experiment was completed successfully.

import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";
import { categories, categoryMeta, featuredProducts, products, type Product } from "./catalog";

type Page =
  | "home"
  | "search"
  | "deals"
  | "wishlist"
  | "cart"
  | "product"
  | "compare"
  | "rewards"
  | "orders"
  | "tracking"
  | "support"
  | "returns"
  | "theme"
  | "profile"
  | "checkout"
  | "success";
type Theme = "sparkle" | "lavender" | "minimal" | "dark";
type CartItem = { id: number; qty: number };
type Order = { id: string; date: string; total: number; status: string; items: CartItem[] };

const iconPaths: Record<string, ReactNode> = {
  home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9M9 20v-6h6v6"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  heart: <path d="M20.8 5.8a5.5 5.5 0 0 0-7.8 0L12 6.9l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 22l8.8-8.4a5.5 5.5 0 0 0 0-7.8Z"/>,
  bag: <><path d="M5 8h14l-1 13H6L5 8Z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/></>,
  user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
  arrow: <path d="m9 18 6-6-6-6"/>,
  back: <path d="m15 18-6-6 6-6"/>,
  star: <path d="m12 2 3 6 6.5 1-4.8 4.6 1.1 6.4-5.8-3-5.8 3 1.1-6.4L2.5 9 9 8l3-6Z"/>,
  spark: <><path d="m12 2 1.5 5.5L19 9l-5.5 1.5L12 16l-1.5-5.5L5 9l5.5-1.5L12 2Z"/><path d="m19 15 .7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7L19 15Z"/></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z"/><path d="M10 21h4"/></>,
  plus: <><path d="M12 5v14M5 12h14"/></>,
  minus: <path d="M5 12h14"/>,
  check: <path d="m5 12 4 4L19 6"/>,
  truck: <><path d="M3 6h11v11H3zM14 10h4l3 3v4h-7z"/><circle cx="7" cy="19" r="2"/><circle cx="18" cy="19" r="2"/></>,
  gift: <><path d="M3 10h18v11H3zM2 6h20v4H2zM12 6v15"/><path d="M12 6H8a2 2 0 1 1 2-2c0 2 2 2 2 2Zm0 0h4a2 2 0 1 0-2-2c0 2-2 2-2 2Z"/></>,
  chat: <path d="M21 15a4 4 0 0 1-4 4H8l-5 3 1.5-5A8 8 0 1 1 21 15Z"/>,
  sliders: <><path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="8" cy="18" r="2"/></>,
  close: <><path d="m6 6 12 12M18 6 6 18"/></>,
  compare: <><path d="M8 7h13M17 3l4 4-4 4M16 17H3M7 13l-4 4 4 4"/></>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/></>,
  camera: <><path d="M4 7h4l2-2h4l2 2h4v12H4z"/><circle cx="12" cy="13" r="3"/></>,
  coupon: <><path d="M3 7a2 2 0 0 0 0 4v6h18v-6a2 2 0 0 0 0-4V5H3v2Z"/><path d="M12 7v2m0 4v2"/></>,
  trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14"/></>,
};

function Icon({ name, size = 20, filled = false }: { name: string; size?: number; filled?: boolean }) {
  return <svg aria-hidden="true" className="icon" width={size} height={size} viewBox="0 0 24 24" fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{iconPaths[name]}</svg>;
}

function useStored<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const saved = localStorage.getItem(`glimmer-${key}`);
      return saved ? JSON.parse(saved) : initial;
    } catch { return initial; }
  });
  useEffect(() => { localStorage.setItem(`glimmer-${key}`, JSON.stringify(value)); }, [key, value]);
  return [value, setValue] as const;
}

function Button({ children, onClick, variant = "primary", disabled = false, type = "button", className = "" }: { children: ReactNode; onClick?: () => void; variant?: "primary" | "soft" | "ghost" | "dark"; disabled?: boolean; type?: "button" | "submit"; className?: string }) {
  return <button type={type} className={`btn btn-${variant} ${className}`} onClick={onClick} disabled={disabled}>{children}</button>;
}

function Header({ title, onBack, right }: { title: string; onBack?: () => void; right?: ReactNode }) {
  return <header className="page-header">
    {onBack ? <button className="icon-btn" onClick={onBack} aria-label="Go back"><Icon name="back" /></button> : <span className="header-spacer" />}
    <h1>{title}</h1>
    <div className="header-action">{right}</div>
  </header>;
}

function Rating({ value }: { value: number }) {
  return <span className="rating"><Icon name="star" size={13} filled /> {value}</span>;
}

function EmptyState({ icon, title, copy, action, onAction }: { icon: string; title: string; copy: string; action: string; onAction: () => void }) {
  return <div className="empty-state"><div className="empty-orb"><Icon name={icon} size={34} /></div><h2>{title}</h2><p>{copy}</p><Button onClick={onAction}>{action}</Button></div>;
}

export default function App() {
  const [page, setPage] = useState<Page>("home");
  const [profile, setProfile] = useStored<{ name: string; email: string } | null>("profile", null);
  const [wishlist, setWishlist] = useStored<number[]>("wishlist", [3]);
  const [cart, setCart] = useStored<CartItem[]>("cart", []);
  const [points, setPoints] = useStored("points", 1240);
  const [orders, setOrders] = useStored<Order[]>("orders", [{ id: "GLM-48291", date: "May 18", total: 66, status: "Out for delivery", items: [{ id: 1, qty: 1 }, { id: 2, qty: 1 }] }]);
  const [theme, setTheme] = useStored<Theme>("theme", "sparkle");
  const [recent, setRecent] = useStored<number[]>("recent", [101, 201, 401, 501]);
  const [searches, setSearches] = useStored<string[]>("searches", ["wireless headphones", "running shoes"]);
  const [selected, setSelected] = useState(products[0]);
  const [compare, setCompare] = useState<number[]>([1, 3]);
  const [catalogCategory, setCatalogCategory] = useState("All");
  const [toast, setToast] = useState("");
  const [returnSubmitted, setReturnSubmitted] = useState(false);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const cartTotal = cart.reduce((sum, item) => sum + (products.find((p) => p.id === item.id)?.price ?? 0) * item.qty, 0);
  const navigate = (next: Page) => { setPage(next); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const openProduct = (product: Product) => {
    setSelected(product);
    setRecent((current) => [product.id, ...current.filter((id) => id !== product.id)].slice(0, 4));
    navigate("product");
  };
  const openCategory = (category: string) => {
    setCatalogCategory(category);
    navigate("search");
  };
  const toggleWish = (id: number) => {
    const active = wishlist.includes(id);
    setWishlist((current) => active ? current.filter((item) => item !== id) : [...current, id]);
    setToast(active ? "Removed from wishlist" : "Saved to your wishlist");
  };
  const addCart = (id: number) => {
    setCart((current) => current.some((item) => item.id === id) ? current.map((item) => item.id === id ? { ...item, qty: item.qty + 1 } : item) : [...current, { id, qty: 1 }]);
    setToast("Added to your bag");
  };
  const updateQty = (id: number, change: number) => setCart((current) => current.map((item) => item.id === id ? { ...item, qty: item.qty + change } : item).filter((item) => item.qty > 0));
  const checkout = () => {
    const order: Order = { id: `GLM-${Math.floor(10000 + Math.random() * 89999)}`, date: "Today", total: cartTotal, status: "Order confirmed", items: cart };
    setOrders((current) => [order, ...current]);
    setPoints((current) => current + Math.round(cartTotal * 10));
    setCart([]);
    navigate("success");
  };

  const screen = (() => {
    switch (page) {
      case "home": return <Home profile={profile} points={points} wishlist={wishlist} onWish={toggleWish} onProduct={openProduct} onNavigate={navigate} onCategory={openCategory} recent={recent} />;
      case "search": return <SearchPage key={catalogCategory} initialCategory={catalogCategory} searches={searches} setSearches={setSearches} wishlist={wishlist} onWish={toggleWish} onProduct={openProduct} onBack={() => navigate("home")} />;
      case "deals": return <DealsPage wishlist={wishlist} onWish={toggleWish} onProduct={openProduct} onBack={() => navigate("home")} />;
      case "wishlist": return <WishlistPage ids={wishlist} onWish={toggleWish} onProduct={openProduct} onNavigate={navigate} />;
      case "cart": return <CartPage cart={cart} total={cartTotal} updateQty={updateQty} onNavigate={navigate} />;
      case "product": return <ProductPage product={selected} wished={wishlist.includes(selected.id)} compared={compare.includes(selected.id)} onWish={() => toggleWish(selected.id)} onAdd={() => addCart(selected.id)} onCompare={() => {
        if (compare.includes(selected.id)) setCompare(compare.filter((id) => id !== selected.id));
        else if (compare.length < 3) { setCompare([...compare, selected.id]); setToast("Added to comparison"); }
        else setToast("You can compare up to 3 products");
      }} onBack={() => navigate("home")} onNavigate={navigate} />;
      case "compare": return <ComparePage ids={compare} setIds={setCompare} onAdd={addCart} onBack={() => navigate("product")} />;
      case "rewards": return <RewardsPage points={points} setPoints={setPoints} onBack={() => navigate("profile")} setToast={setToast} />;
      case "orders": return <OrdersPage orders={orders} onNavigate={navigate} />;
      case "tracking": return <TrackingPage order={orders[0]} onBack={() => navigate("orders")} onNavigate={navigate} />;
      case "support": return <SupportPage onBack={() => navigate("profile")} onNavigate={navigate} />;
      case "returns": return <ReturnsPage submitted={returnSubmitted} setSubmitted={setReturnSubmitted} onBack={() => navigate("support")} />;
      case "theme": return <ThemePage theme={theme} setTheme={setTheme} onBack={() => navigate("profile")} />;
      case "profile": return <ProfilePage profile={profile} setProfile={setProfile} theme={theme} points={points} orders={orders.length} onNavigate={navigate} />;
      case "checkout": return <CheckoutPage total={cartTotal} count={cartCount} onBack={() => navigate("cart")} onComplete={checkout} />;
      case "success": return <SuccessPage points={Math.round(cartTotal * 10)} onNavigate={navigate} order={orders[0]} />;
    }
  })();

  const hideNav = ["product", "compare", "checkout", "success", "tracking", "returns", "theme", "rewards", "support", "search", "deals"].includes(page);
  return <div className={`app theme-${theme}`}>
    <div className="sparkle sparkle-one" /><div className="sparkle sparkle-two" />
    <main className="phone">{screen}</main>
    {!hideNav && <BottomNav page={page} count={cartCount} navigate={navigate} />}
    {toast && <div className="toast"><span className="toast-check"><Icon name="check" size={14} /></span>{toast}</div>}
  </div>;
}

function BottomNav({ page, count, navigate }: { page: Page; count: number; navigate: (p: Page) => void }) {
  const tabs: { id: Page; label: string; icon: string }[] = [
    { id: "home", label: "Home", icon: "home" }, { id: "search", label: "Discover", icon: "search" },
    { id: "wishlist", label: "Saved", icon: "heart" }, { id: "cart", label: "Bag", icon: "bag" }, { id: "profile", label: "You", icon: "user" },
  ];
  return <nav className="bottom-nav">{tabs.map((tab) => <button key={tab.id} className={page === tab.id ? "active" : ""} onClick={() => navigate(tab.id)}>
    <span className="nav-icon"><Icon name={tab.icon} size={21} filled={page === tab.id && tab.icon === "heart"} />{tab.id === "cart" && count > 0 && <b>{count}</b>}</span><span>{tab.label}</span>
  </button>)}</nav>;
}

function Home({ profile, points, wishlist, onWish, onProduct, onNavigate, onCategory, recent }: { profile: { name: string } | null; points: number; wishlist: number[]; onWish: (id: number) => void; onProduct: (p: Product) => void; onNavigate: (p: Page) => void; onCategory: (category: string) => void; recent: number[] }) {
  const alertProduct = products.find((p) => p.category === "Electronics" && p.oldPrice) ?? products[0];
  const trendProduct = products.find((p) => p.category === "Home & Kitchen") ?? products[0];
  return <div className="screen home-screen">
    <header className="home-head"><div><p>Good morning{profile ? "," : ""}</p><h1>{profile?.name || "Find your next glow"}</h1></div><button className="avatar" onClick={() => onNavigate("profile")} aria-label="Open profile">{profile?.name?.[0]?.toUpperCase() || <Icon name="user" />}</button></header>
    <button className="search-launch" onClick={() => onNavigate("search")}><Icon name="search" /><span>Search your dream finds</span><Icon name="sliders" size={18} /></button>
    <section className="hero-card"><div className="hero-copy"><span className="eyebrow"><Icon name="spark" size={13} /> THE BIG MARKETPLACE EDIT</span><h2>Everything you love.</h2><p>Fresh finds across tech, style, home and more.</p><Button variant="dark" onClick={() => onNavigate("deals")}>Shop the edit <Icon name="arrow" size={16} /></Button></div><img src={featuredProducts[0].image} alt={featuredProducts[0].name} /></section>
    <SectionTitle title="Shop by category" action="View all" onClick={() => onCategory("All")} />
    <div className="catalog-categories">{categoryMeta.map((category) => <button key={category.name} onClick={() => onCategory(category.name)}><span><img src={category.image} alt="" /><b>{category.shortName.slice(0, 1)}</b></span><small>{category.shortName}</small></button>)}</div>
    <div className="quick-row">
      <button onClick={() => onNavigate("rewards")}><span className="quick-icon purple"><Icon name="gift" /></span><span><b>{points.toLocaleString()}</b><small>Sparkle points</small></span><Icon name="arrow" size={16} /></button>
      <button onClick={() => onNavigate("deals")}><span className="quick-icon pink"><Icon name="clock" /></span><span><b>02:18:44</b><small>Flash sale</small></span><Icon name="arrow" size={16} /></button>
    </div>
    <SectionTitle title="Picked for you" action="See all" onClick={() => onNavigate("search")} />
    <div className="product-scroll">{featuredProducts.map((p) => <ProductCard key={p.id} product={p} wished={wishlist.includes(p.id)} onWish={onWish} onOpen={onProduct} />)}</div>
    <div className="price-alert"><div className="alert-icon"><Icon name="bell" /></div><div><span>Price drop alert</span><b>{alertProduct.name} is now ${alertProduct.price}</b></div><button onClick={() => onProduct(alertProduct)}><Icon name="arrow" /></button></div>
    <SectionTitle title="Trending now" action="Explore" onClick={() => onNavigate("deals")} />
    <div className="wide-product" onClick={() => onProduct(trendProduct)}><img src={trendProduct.image} alt={trendProduct.name} /><div><span>HOME TREND</span><h3>Easy upgrades, big impact</h3><p>Refresh your space with practical new favorites.</p><b>Shop the trend <Icon name="arrow" size={15} /></b></div></div>
    <SectionTitle title="Recently viewed" />
    <div className="recent-list">{recent.map((id) => products.find((p) => p.id === id)).filter(Boolean).map((p) => <button key={p!.id} onClick={() => onProduct(p!)}><img src={p!.image} alt="" /><span><b>{p!.name}</b><small>${p!.price}</small></span><Icon name="arrow" size={17} /></button>)}</div>
    <SectionTitle title="For you" />
    <div className="for-you"><Icon name="spark" /><div><h3>More ways to make it yours</h3><p>Recommendations from categories you explore.</p></div><button onClick={() => onCategory("All")}>View</button></div>
  </div>;
}

function SectionTitle({ title, action, onClick }: { title: string; action?: string; onClick?: () => void }) {
  return <div className="section-title"><h2>{title}</h2>{action && <button onClick={onClick}>{action} <Icon name="arrow" size={14} /></button>}</div>;
}

function ProductCard({ product, wished, onWish, onOpen }: { product: Product; wished: boolean; onWish: (id: number) => void; onOpen: (p: Product) => void }) {
  return <article className="product-card"><div className="product-image" onClick={() => onOpen(product)}><img src={product.image} alt={product.name} />{product.badge && <span className="badge">{product.badge}</span>}<button className={`wish ${wished ? "on" : ""}`} onClick={(e) => { e.stopPropagation(); onWish(product.id); }} aria-label="Toggle wishlist"><Icon name="heart" size={18} filled={wished} /></button></div><button className="product-info" onClick={() => onOpen(product)}><small>{product.brand}</small><h3>{product.name}</h3><div><b>${product.price}</b>{product.oldPrice && <del>${product.oldPrice}</del>}<Rating value={product.rating} /></div></button></article>;
}

function SearchPage({ initialCategory, searches, setSearches, wishlist, onWish, onProduct, onBack }: { initialCategory: string; searches: string[]; setSearches: (v: string[]) => void; wishlist: number[]; onWish: (id: number) => void; onProduct: (p: Product) => void; onBack: () => void }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState(initialCategory);
  const [sort, setSort] = useState("Recommended");
  const [maxPrice, setMaxPrice] = useState(500);
  const [minRating, setMinRating] = useState(0);
  const results = useMemo(() => {
    const terms = query.toLowerCase().trim().split(/\s+/).filter(Boolean);
    const filtered = products.filter((p) => {
      const haystack = `${p.name} ${p.brand} ${p.category} ${p.subcategory} ${p.description}`.toLowerCase();
      return (category === "All" || p.category === category)
        && p.price <= maxPrice
        && p.rating >= minRating
        && terms.every((term) => haystack.includes(term));
    });
    if (sort === "Price: Low") return [...filtered].sort((a, b) => a.price - b.price);
    if (sort === "Price: High") return [...filtered].sort((a, b) => b.price - a.price);
    if (sort === "Top rated") return [...filtered].sort((a, b) => b.rating - a.rating);
    return filtered;
  }, [category, maxPrice, minRating, query, sort]);
  const submit = (term: string) => { setQuery(term); if (term.trim()) setSearches([term, ...searches.filter((s) => s !== term)].slice(0, 5)); };
  return <div className="screen"><Header title={category === "All" ? "Discover" : categoryMeta.find((item) => item.name === category)?.shortName || "Discover"} onBack={onBack} />
    <div className="search-input"><Icon name="search" /><input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit(query)} placeholder="Search products, brands..." />{query && <button onClick={() => setQuery("")}><Icon name="close" size={17} /></button>}</div>
    {!query && category === "All" && <><div className="mini-title"><h3>Recently searched</h3><button onClick={() => setSearches([])}>Clear</button></div><div className="chips">{searches.map((term) => <button key={term} onClick={() => submit(term)}><Icon name="clock" size={14} />{term}</button>)}</div><div className="suggestions"><h3>Popular searches</h3>{["5G smartphone", "cotton shirts", "kitchen storage", "running shoes"].map((term) => <button key={term} onClick={() => submit(term)}><Icon name="spark" size={16} /><span>{term}</span><Icon name="arrow" size={16} /></button>)}</div></>}
    <div className="category-scroll">{["All", ...categories].map((c) => <button className={category === c ? "active" : ""} onClick={() => setCategory(c)} key={c}>{c === "All" ? c : categoryMeta.find((item) => item.name === c)?.shortName}</button>)}</div>
    <div className="market-filters">
      <label>Price<select value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))}><option value="25">Under $25</option><option value="50">Under $50</option><option value="100">Under $100</option><option value="250">Under $250</option><option value="500">Any price</option></select></label>
      <label>Rating<select value={minRating} onChange={(e) => setMinRating(Number(e.target.value))}><option value="0">Any rating</option><option value="4">4.0+ stars</option><option value="4.5">4.5+ stars</option><option value="4.8">4.8+ stars</option></select></label>
      <label>Sort<select value={sort} onChange={(e) => setSort(e.target.value)}><option>Recommended</option><option>Price: Low</option><option>Price: High</option><option>Top rated</option></select></label>
    </div>
    <div className="result-head"><span>{results.length} marketplace finds</span>{(maxPrice !== 500 || minRating !== 0) && <button onClick={() => { setMaxPrice(500); setMinRating(0); }}>Reset filters</button>}</div>
    {results.length ? <div className="product-grid">{results.map((p) => <ProductCard key={p.id} product={p} wished={wishlist.includes(p.id)} onWish={onWish} onOpen={onProduct} />)}</div> : <EmptyState icon="search" title="No exact matches" copy="Try a wider price range, another category, or a different search." action="Clear filters" onAction={() => { setQuery(""); setCategory("All"); setMaxPrice(500); setMinRating(0); }} />}
  </div>;
}

function DealsPage({ wishlist, onWish, onProduct, onBack }: { wishlist: number[]; onWish: (id: number) => void; onProduct: (p: Product) => void; onBack: () => void }) {
  const [seconds, setSeconds] = useState(8324);
  useEffect(() => { const timer = window.setInterval(() => setSeconds((s) => s > 0 ? s - 1 : 86399), 1000); return () => clearInterval(timer); }, []);
  const h = String(Math.floor(seconds / 3600)).padStart(2, "0"), m = String(Math.floor(seconds % 3600 / 60)).padStart(2, "0"), s = String(seconds % 60).padStart(2, "0");
  return <div className="screen"><Header title="Deals & drops" onBack={onBack} right={<Icon name="spark" />} />
    <div className="deal-hero"><span>FLASH GLOW SALE</span><h2>Up to 40% off</h2><p>Demo promotion ends in</p><div className="timer">{[h, m, s].map((v, i) => <span key={i}><b>{v}</b><small>{["HRS", "MIN", "SEC"][i]}</small></span>)}</div></div>
    <div className="coupon-card"><Icon name="coupon" /><div><small>YOUR EXCLUSIVE CODE</small><b>SPARKLE20</b></div><button onClick={() => navigator.clipboard?.writeText("SPARKLE20")}>Copy</button></div>
    <SectionTitle title="Today's marketplace deals" />
    <div className="product-grid">{products.filter((p) => p.oldPrice).slice(0, 40).map((p) => <ProductCard key={p.id} product={p} wished={wishlist.includes(p.id)} onWish={onWish} onOpen={onProduct} />)}</div>
  </div>;
}

function WishlistPage({ ids, onWish, onProduct, onNavigate }: { ids: number[]; onWish: (id: number) => void; onProduct: (p: Product) => void; onNavigate: (p: Page) => void }) {
  const items = products.filter((p) => ids.includes(p.id));
  return <div className="screen nav-screen"><Header title="Saved for you" right={<span className="count-pill">{items.length}</span>} />{items.length === 0 ? <EmptyState icon="heart" title="Save what makes you sparkle" copy="Tap the heart on anything you love and find it waiting here." action="Discover products" onAction={() => onNavigate("search")} /> : <><div className="notice"><Icon name="bell" size={18} /><span>Price alerts are on for your saved items</span></div><div className="product-grid">{items.map((p) => <ProductCard key={p.id} product={p} wished onWish={onWish} onOpen={onProduct} />)}</div></>}</div>;
}

function CartPage({ cart, total, updateQty, onNavigate }: { cart: CartItem[]; total: number; updateQty: (id: number, c: number) => void; onNavigate: (p: Page) => void }) {
  return <div className="screen nav-screen"><Header title="Your bag" right={<span className="count-pill">{cart.length}</span>} />{cart.length === 0 ? <EmptyState icon="bag" title="Your bag is feeling light" copy="Fill it with something lovely. Your glow picks are only a tap away." action="Start shopping" onAction={() => onNavigate("home")} /> : <><div className="shipping-progress"><div><span>You're $50 away from free shipping</span><b>55%</b></div><i><em /></i></div><div className="cart-list">{cart.map((item) => { const p = products.find((product) => product.id === item.id)!; return <div className="cart-item" key={item.id}><img src={p.image} alt={p.name} /><div><small>{p.brand}</small><h3>{p.name}</h3><b>${p.price}</b><div className="qty"><button onClick={() => updateQty(p.id, -1)}><Icon name="minus" size={15} /></button><span>{item.qty}</span><button onClick={() => updateQty(p.id, 1)}><Icon name="plus" size={15} /></button></div></div><button className="remove" onClick={() => updateQty(p.id, -item.qty)}><Icon name="trash" size={17} /></button></div>})}</div><div className="promo-row"><Icon name="coupon" /><span>Add promo code</span><Icon name="arrow" size={17} /></div><div className="summary"><p><span>Subtotal</span><b>${total.toFixed(2)}</b></p><p><span>Shipping</span><b>Calculated next</b></p><p className="total"><span>Total</span><b>${total.toFixed(2)}</b></p></div><Button className="full sticky-cta" onClick={() => onNavigate("checkout")}>Checkout securely <Icon name="arrow" size={17} /></Button></>}</div>;
}

function ProductPage({ product, wished, compared, onWish, onAdd, onCompare, onBack, onNavigate }: { product: Product; wished: boolean; compared: boolean; onWish: () => void; onAdd: () => void; onCompare: () => void; onBack: () => void; onNavigate: (p: Page) => void }) {
  const [helpful, setHelpful] = useState(false);
  return <div className="screen product-page"><div className="product-visual"><img src={product.image} alt={product.name} /><button className="floating back" onClick={onBack}><Icon name="back" /></button><button className={`floating heart ${wished ? "on" : ""}`} onClick={onWish}><Icon name="heart" filled={wished} /></button>{product.badge && <span className="big-badge">{product.badge}</span>}</div>
    <div className="product-detail"><small className="brand">{product.category} · {product.brand}</small><h1>{product.name}</h1><div className="product-meta"><Rating value={product.rating} /><button onClick={() => document.getElementById("reviews")?.scrollIntoView({ behavior: "smooth" })}>{84 + product.id % 117} reviews</button></div><div className="price"><b>${product.price}</b>{product.oldPrice && <del>${product.oldPrice}</del>}</div><p className="description">{product.description}</p>
      <div className="stock-line"><span className={product.stock < 10 ? "low" : ""}>{product.stock < 10 ? `Only ${product.stock} left in demo stock` : `${product.stock} available in demo inventory`}</span><small>Demo catalog data</small></div>
      <div className="benefit-row"><span><Icon name="spark" />Quality checked</span><span><Icon name="truck" />Free returns</span></div>
      <button className={`compare-toggle ${compared ? "active" : ""}`} onClick={onCompare}><Icon name="compare" /><span>{compared ? "Added to comparison" : "Add to comparison"}</span><Icon name={compared ? "check" : "plus"} size={17} /></button>
      <div className="specs">{Object.entries(product.specs).map(([key, value]) => <div key={key}><small>{key}</small><b>{value}</b></div>)}</div>
      <section id="reviews" className="reviews"><SectionTitle title="Customer reviews" action="See all" /><div className="review-summary"><b>{product.rating}</b><span><span className="stars">★★★★★</span><small>Based on {84 + product.id % 117} reviews</small></span></div><article className="review"><div className="review-head"><span className="reviewer">AM</span><div><b>Amelia M.</b><small>Verified buyer · 3 days ago</small></div><span className="stars">★★★★★</span></div><h3>Exactly what I was looking for</h3><p>Good quality, accurately described, and packed with care. I would happily recommend this product.</p><div className="photo-placeholders"><span><Icon name="camera" /></span><span><Icon name="camera" /></span></div><button className={helpful ? "helpful active" : "helpful"} onClick={() => setHelpful(!helpful)}><Icon name="heart" size={15} filled={helpful} /> Helpful {helpful ? "25" : "24"}</button></article></section>
    </div>
    <div className="product-cta"><Button variant="soft" onClick={() => onNavigate("compare")}><Icon name="compare" /></Button><Button className="grow" onClick={onAdd}>Add to bag · ${product.price}</Button></div>
  </div>;
}

function ComparePage({ ids, setIds, onAdd, onBack }: { ids: number[]; setIds: (ids: number[]) => void; onAdd: (id: number) => void; onBack: () => void }) {
  const items = ids.map((id) => products.find((p) => p.id === id)!).filter(Boolean);
  return <div className="screen"><Header title="Compare" onBack={onBack} right={<span className="count-pill">{items.length}/3</span>} /><p className="page-intro">Compare up to three glow picks side by side.</p>
    <div className="compare-grid">{items.map((p) => <div className="compare-product" key={p.id}><button className="compare-remove" onClick={() => setIds(ids.filter((id) => id !== p.id))}><Icon name="close" size={14} /></button><img src={p.image} alt={p.name} /><small>{p.brand}</small><h3>{p.name}</h3><b>${p.price}</b><Rating value={p.rating} /></div>)}{items.length < 3 && <button className="compare-add" onClick={() => { const next = products.find((p) => !ids.includes(p.id)); if (next) setIds([...ids, next.id]); }}><Icon name="plus" /><span>Add product</span></button>}</div>
    {items.length > 0 && <div className="comparison-table">{["Price", "Rating", "Size", "Best for"].map((label) => <div className="compare-row" key={label}><b>{label}</b>{items.map((p) => <span key={p.id}>{label === "Price" ? `$${p.price}` : label === "Rating" ? `${p.rating} / 5` : label === "Size" ? p.specs.Size : Object.values(p.specs)[1]}</span>)}</div>)}</div>}
    <div className="compare-actions">{items.map((p) => <Button key={p.id} variant="soft" onClick={() => onAdd(p.id)}>Add {p.name.split(" ")[0]}</Button>)}</div>
  </div>;
}

function RewardsPage({ points, setPoints, onBack, setToast }: { points: number; setPoints: (v: number | ((n: number) => number)) => void; onBack: () => void; setToast: (s: string) => void }) {
  const redeem = (cost: number) => { if (points >= cost) { setPoints((p) => p - cost); setToast("Reward added to your account"); } else setToast("Keep sparkling — more points needed"); };
  return <div className="screen rewards-page"><Header title="Sparkle rewards" onBack={onBack} />
    <div className="points-card"><span><Icon name="spark" /> PEARL TIER</span><strong>{points.toLocaleString()}</strong><p>sparkle points</p><div><i><em style={{ width: `${Math.min(100, points / 20)}%` }} /></i><small>{Math.max(0, 2000 - points)} points to Amethyst</small></div></div>
    <div className="mini-title"><h3>Redeem your sparkle</h3><span>Demo rewards</span></div>
    <div className="reward-list">{[{ title: "$5 off your next order", cost: 500 }, { title: "Free express shipping", cost: 750 }, { title: "20% off one glow pick", cost: 1200 }].map((reward) => <div key={reward.title}><span className="reward-icon"><Icon name="gift" /></span><span><b>{reward.title}</b><small>{reward.cost} points</small></span><button disabled={points < reward.cost} onClick={() => redeem(reward.cost)}>Redeem</button></div>)}</div>
    <SectionTitle title="Points history" /><div className="history"><div><span><Icon name="bag" /></span><p><b>Cloud Dew order</b><small>May 18</small></p><strong>+660</strong></div><div><span><Icon name="star" /></span><p><b>Review bonus</b><small>May 14</small></p><strong>+50</strong></div><div><span><Icon name="gift" /></span><p><b>Welcome sparkle</b><small>May 1</small></p><strong>+500</strong></div></div>
  </div>;
}

function OrdersPage({ orders, onNavigate }: { orders: Order[]; onNavigate: (p: Page) => void }) {
  return <div className="screen nav-screen"><Header title="Your orders" />{orders.length === 0 ? <EmptyState icon="truck" title="No orders yet" copy="When you place an order, its journey will appear here." action="Start shopping" onAction={() => onNavigate("home")} /> : <div className="orders-list">{orders.map((order, index) => <article key={order.id}><div className="order-top"><span><small>ORDER {order.id}</small><b>{order.status}</b></span><span className={index === 0 ? "live-dot" : ""}>{order.date}</span></div><div className="order-products">{order.items.slice(0, 3).map((item) => <img key={item.id} src={products.find((p) => p.id === item.id)?.image} alt="" />)}<span><b>${order.total.toFixed(2)}</b><small>{order.items.length} items</small></span></div><Button variant={index === 0 ? "primary" : "soft"} className="full" onClick={() => onNavigate("tracking")}>{index === 0 ? "Track order" : "View order"} <Icon name="arrow" size={16} /></Button></article>)}</div>}</div>;
}

function TrackingPage({ order, onBack, onNavigate }: { order: Order; onBack: () => void; onNavigate: (p: Page) => void }) {
  const steps = [{ title: "Order confirmed", sub: "May 18 · 9:42 AM", done: true }, { title: "Packed with care", sub: "May 19 · 2:15 PM", done: true }, { title: "Out for delivery", sub: "Today · 8:04 AM", done: true, active: true }, { title: "Delivered", sub: "Estimated today by 8 PM", done: false }];
  return <div className="screen"><Header title="Track order" onBack={onBack} right={<button className="icon-btn" onClick={() => onNavigate("support")}><Icon name="chat" /></button>} />
    <div className="delivery-card"><span className="delivery-icon"><Icon name="truck" size={27} /></span><div><small>ESTIMATED DELIVERY</small><h2>Today, by 8 PM</h2><p>Your sparkle is almost there.</p></div></div>
    <div className="map-demo"><div className="route-line" /><span className="map-pin warehouse"><Icon name="bag" size={15} /></span><span className="map-pin truck-pin"><Icon name="truck" size={16} /></span><span className="map-pin home-pin"><Icon name="home" size={16} /></span><small>Simulated live delivery map</small></div>
    <div className="timeline">{steps.map((step) => <div className={`${step.done ? "done" : ""} ${step.active ? "current" : ""}`} key={step.title}><span className="step-dot">{step.done ? <Icon name="check" size={13} /> : ""}</span><div><h3>{step.title}</h3><p>{step.sub}</p>{step.active && <span className="status-update">Courier is 6 stops away</span>}</div></div>)}</div>
    <div className="order-detail-card"><div><span>Order details</span><small>{order?.id || "GLM-48291"}</small></div>{order?.items?.map((item) => { const p = products.find((x) => x.id === item.id); return <p key={item.id}><span>{item.qty} × {p?.name}</span><b>${((p?.price || 0) * item.qty).toFixed(2)}</b></p> })}<div className="detail-total"><span>Total</span><b>${order?.total?.toFixed(2) || "66.00"}</b></div></div>
    <Button variant="soft" className="full" onClick={() => onNavigate("support")}><Icon name="chat" /> Need help with this order?</Button>
  </div>;
}

function ProfilePage({ profile, setProfile, theme, points, orders, onNavigate }: { profile: { name: string; email: string } | null; setProfile: (p: { name: string; email: string } | null) => void; theme: Theme; points: number; orders: number; onNavigate: (p: Page) => void }) {
  const [editing, setEditing] = useState(!profile);
  const [name, setName] = useState(profile?.name || "");
  const [email, setEmail] = useState(profile?.email || "");
  const save = (e: FormEvent) => { e.preventDefault(); if (name.trim() && email.trim()) { setProfile({ name: name.trim(), email: email.trim() }); setEditing(false); } };
  if (editing) return <div className="screen auth-screen"><button className="auth-mark"><Icon name="spark" size={26} /></button><span className="eyebrow">YOUR PERSONAL GLOW SPACE</span><h1>{profile ? "Update your profile" : "Make it yours"}</h1><p>{profile ? "Keep your details shining and up to date." : "Create your profile to personalize recommendations, rewards, orders, and more."}</p><form onSubmit={save}><label>Your name<input value={name} onChange={(e) => setName(e.target.value)} placeholder="How should we greet you?" required /></label><label>Email address<input value={email} type="email" onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required /></label><Button type="submit" className="full">{profile ? "Save changes" : "Create my profile"} <Icon name="arrow" size={17} /></Button></form>{profile && <Button variant="ghost" onClick={() => setEditing(false)}>Cancel</Button>}<small className="data-note">Your profile is stored locally on this device for this demo.</small></div>;
  const menu = [{ icon: "truck", label: "Orders & tracking", detail: `${orders} active`, page: "orders" as Page }, { icon: "gift", label: "Sparkle rewards", detail: `${points.toLocaleString()} points`, page: "rewards" as Page }, { icon: "spark", label: "App appearance", detail: theme, page: "theme" as Page }, { icon: "chat", label: "Help & support", detail: "We're here", page: "support" as Page }];
  return <div className="screen nav-screen"><Header title="Your space" right={<button className="text-btn" onClick={() => setEditing(true)}>Edit</button>} /><div className="profile-card"><div className="profile-avatar">{profile.name[0].toUpperCase()}</div><div><h2>{profile.name}</h2><p>{profile.email}</p><span><Icon name="spark" size={12} /> Pearl member</span></div></div><div className="profile-stats"><button onClick={() => onNavigate("orders")}><b>{orders}</b><small>Orders</small></button><button onClick={() => onNavigate("wishlist")}><Icon name="heart" size={20} /><small>Saved</small></button><button onClick={() => onNavigate("rewards")}><b>{points}</b><small>Points</small></button></div><div className="menu-list">{menu.map((item) => <button key={item.label} onClick={() => onNavigate(item.page)}><span className="menu-icon"><Icon name={item.icon} /></span><span><b>{item.label}</b><small>{item.detail}</small></span><Icon name="arrow" size={17} /></button>)}</div><Button variant="ghost" className="full signout" onClick={() => setProfile(null)}>Sign out</Button></div>;
}

function ThemePage({ theme, setTheme, onBack }: { theme: Theme; setTheme: (t: Theme) => void; onBack: () => void }) {
  const themes: { id: Theme; name: string; desc: string; swatches: string[] }[] = [{ id: "sparkle", name: "Pastel sparkle", desc: "Pink, blue and a touch of magic", swatches: ["pink", "purple", "blue"] }, { id: "lavender", name: "Lavender dream", desc: "Soft violet and calming lilac", swatches: ["lavender", "violet", "cream"] }, { id: "minimal", name: "Soft minimal", desc: "Warm neutrals, quietly polished", swatches: ["white", "sand", "charcoal"] }, { id: "dark", name: "Midnight glow", desc: "Deep plum with luminous accents", swatches: ["night", "plum", "glow"] }];
  return <div className="screen"><Header title="App appearance" onBack={onBack} /><p className="page-intro">Choose the mood that feels most like you. Your selection is saved on this device.</p><div className="theme-list">{themes.map((item) => <button className={theme === item.id ? "selected" : ""} key={item.id} onClick={() => setTheme(item.id)}><span className={`theme-preview preview-${item.id}`}><i /><i /><i /></span><span><b>{item.name}</b><small>{item.desc}</small><span className="swatches">{item.swatches.map((s) => <i className={s} key={s} />)}</span></span><span className="radio">{theme === item.id && <Icon name="check" size={14} />}</span></button>)}</div></div>;
}

function SupportPage({ onBack, onNavigate }: { onBack: () => void; onNavigate: (p: Page) => void }) {
  const [chat, setChat] = useState(false), [message, setMessage] = useState(""), [messages, setMessages] = useState<string[]>([]);
  if (chat) return <div className="screen chat-page"><Header title="Glimmer support" onBack={() => setChat(false)} right={<span className="online">Online</span>} /><div className="agent"><span>G</span><div><b>Mila, support stylist</b><small>Typically replies instantly</small></div></div><div className="chat-messages"><p className="bot">Hi! I’m Mila, your demo support assistant. How can I help make things sparkle today?</p>{messages.map((m, i) => <p className="mine" key={i}>{m}</p>)}</div><div className="chat-compose"><input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Type a message..." /><button onClick={() => { if (message.trim()) { setMessages([...messages, message]); setMessage(""); } }}><Icon name="arrow" /></button></div></div>;
  const faqs = ["Where is my order?", "How do returns work?", "Can I change my delivery address?", "How do Sparkle Points work?"];
  return <div className="screen"><Header title="Help & support" onBack={onBack} /><div className="support-hero"><span><Icon name="chat" size={27} /></span><h2>How can we help?</h2><p>Answers, reassurance, and real support.</p><Button onClick={() => setChat(true)}>Start a support chat</Button></div><div className="support-actions"><button onClick={() => onNavigate("tracking")}><Icon name="truck" /><span>Track an order</span><Icon name="arrow" size={17} /></button><button onClick={() => onNavigate("returns")}><Icon name="compare" /><span>Cancel or return</span><Icon name="arrow" size={17} /></button></div><SectionTitle title="Frequently asked" /><div className="faq-list">{faqs.map((faq) => <details key={faq}><summary>{faq}<Icon name="plus" size={18} /></summary><p>This is a simulated help answer. Our support team can provide personalized guidance through chat.</p></details>)}</div></div>;
}

function ReturnsPage({ submitted, setSubmitted, onBack }: { submitted: boolean; setSubmitted: (v: boolean) => void; onBack: () => void }) {
  const [reason, setReason] = useState("");
  if (submitted) return <div className="screen"><Header title="Return request" onBack={onBack} /><div className="success-state"><div className="success-orb"><Icon name="check" size={35} /></div><h1>Request received</h1><p>Your simulated return request is in. We’ll email the next steps and a printable label shortly.</p><span>RETURN REF · RT-2048</span><Button onClick={onBack}>Back to support</Button></div></div>;
  return <div className="screen"><Header title="Cancel or return" onBack={onBack} /><p className="page-intro">Choose an order and tell us what happened. Returns are free within 30 days.</p><div className="select-order"><span><img src={products[0].image} alt="" /><span><b>Order GLM-48291</b><small>2 items · Delivered May 18</small></span></span><Icon name="check" /></div><label className="field-label">What would you like to do?<select><option>Return an item</option><option>Cancel my order</option><option>Replace an item</option></select></label><label className="field-label">Reason<select value={reason} onChange={(e) => setReason(e.target.value)}><option value="">Select a reason</option><option>Changed my mind</option><option>Item arrived damaged</option><option>Wrong item received</option></select></label><label className="field-label">Anything else?<textarea placeholder="Add optional details..." /></label><Button disabled={!reason} className="full" onClick={() => setSubmitted(true)}>Submit demo request</Button></div>;
}

function CheckoutPage({ total, count, onBack, onComplete }: { total: number; count: number; onBack: () => void; onComplete: () => void }) {
  const [step, setStep] = useState(1), [loading, setLoading] = useState(false);
  const pay = () => { setLoading(true); window.setTimeout(() => { setLoading(false); onComplete(); }, 1200); };
  return <div className="screen checkout"><Header title="Checkout" onBack={onBack} right={<span className="secure"><Icon name="check" size={13} /> Secure</span>} /><div className="checkout-steps"><span className="done"><Icon name="check" /></span><i /><span className={step >= 2 ? "done" : ""}>{step >= 2 ? <Icon name="check" /> : "2"}</span><i /><span>3</span></div>
    {step === 1 ? <><h2>Where should we send it?</h2><label className="field-label">Full name<input defaultValue="" placeholder="Recipient name" /></label><label className="field-label">Street address<input placeholder="123 Sparkle Lane" /></label><div className="field-split"><label className="field-label">City<input placeholder="Brooklyn" /></label><label className="field-label">ZIP<input placeholder="11201" /></label></div><Button className="full" onClick={() => setStep(2)}>Continue to payment</Button></> : <><h2>Payment</h2><div className="demo-label">DEMO PAYMENT — NO REAL CHARGE</div><label className="field-label">Card number<input defaultValue="4242 4242 4242 4242" /></label><div className="field-split"><label className="field-label">Expiry<input defaultValue="12/29" /></label><label className="field-label">CVC<input defaultValue="123" /></label></div><div className="checkout-summary"><p><span>{count} items</span><b>${total.toFixed(2)}</b></p><p><span>Shipping</span><b>Free</b></p><p><span>Total</span><b>${total.toFixed(2)}</b></p></div><Button className="full" onClick={pay} disabled={loading}>{loading ? <><span className="loader" /> Processing...</> : <>Pay ${total.toFixed(2)} <Icon name="arrow" size={16} /></>}</Button></>}
  </div>;
}

function SuccessPage({ onNavigate, order }: { points: number; onNavigate: (p: Page) => void; order: Order }) {
  return <div className="screen confirmation"><div className="confetti one" /><div className="confetti two" /><div className="success-orb"><Icon name="check" size={38} /></div><span className="eyebrow"><Icon name="spark" size={13} /> ORDER CONFIRMED</span><h1>Your sparkle is on its way!</h1><p>We’ve sent the details to your email. Now sit back and let us pack a little joy.</p><div className="confirmation-card"><span><small>ORDER NUMBER</small><b>{order?.id || "GLM-NEW"}</b></span><span><small>ESTIMATED DELIVERY</small><b>May 23–24</b></span><div><Icon name="gift" /><p><b>+{Math.round((order?.total || 0) * 10)} sparkle points</b><small>Added to your rewards balance</small></p></div></div><Button className="full" onClick={() => onNavigate("tracking")}>Track my order <Icon name="truck" size={18} /></Button><Button variant="ghost" onClick={() => onNavigate("home")}>Continue shopping</Button></div>;
}

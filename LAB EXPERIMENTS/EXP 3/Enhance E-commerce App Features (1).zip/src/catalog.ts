export type Product = {
  id: number;
  name: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  category: string;
  subcategory: string;
  image: string;
  badge?: string;
  description: string;
  stock: number;
  specs: Record<string, string>;
};

export const categories = [
  "Fashion & Clothing",
  "Electronics",
  "Home & Kitchen",
  "Beauty & Personal Care",
  "Footwear",
  "Bags & Accessories",
  "Grocery & Food",
  "Books & Stationery",
  "Sports & Fitness",
  "Toys & Baby Products",
  "Automotive",
  "Appliances",
  "Gaming",
  "Pet Supplies",
] as const;

export type Category = (typeof categories)[number];

type CategorySeed = {
  category: Category;
  shortName: string;
  brands: string[];
  names: string[];
  images: string[];
  basePrice: number;
  description: string;
  specs: [string, string[]][];
};

const image = (id: string) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=600&q=82`;

const seeds: CategorySeed[] = [
  {
    category: "Fashion & Clothing",
    shortName: "Fashion",
    brands: ["North & Loom", "Mira", "Urban Thread", "Indigo Bay", "Aarvi"],
    names: ["Essential Cotton T-Shirt", "Oxford Slim Shirt", "Classic Straight Jeans", "Floral Midi Dress", "Silk Blend Saree", "Embroidered Kurta", "Everyday Denim Jacket", "Relaxed Linen Shirt", "High-Rise Wide Jeans", "Pleated Evening Dress", "Handloom Cotton Saree", "Printed Anarkali Kurta", "Utility Bomber Jacket", "Oversized Graphic Tee", "Tailored Chino Trousers"],
    images: ["1576188973526-0e5d7047b0cf", "1647152777991-4298db91a1f6", "1529139574466-a303027c1d8b", "1490481651871-ab68de25d43d", "1515886657613-9f3515b0c78f"],
    basePrice: 24,
    description: "Comfortable, well-finished apparel designed for everyday style and easy pairing.",
    specs: [["Material", ["Cotton", "Linen blend", "Denim", "Viscose"]], ["Fit", ["Regular", "Relaxed", "Slim", "Tailored"]], ["Care", ["Machine wash", "Gentle wash"]]],
  },
  {
    category: "Electronics",
    shortName: "Electronics",
    brands: ["NovaTech", "Orion", "Pulse", "Vertex", "Aero"],
    names: ["Nova X5 5G Smartphone", "AirLite 14 Laptop", "Tab S10 Tablet", "QuietMax ANC Headphones", "PulseFit Smartwatch", "RoomBeat Bluetooth Speaker", "PixelPro Camera Phone", "CreatorBook 15 Laptop", "MiniPad 8 Tablet", "Studio Wireless Earbuds", "Active 2 Smartwatch", "SoundDock Portable Speaker", "PowerCore 20000 Power Bank", "StreamView Webcam", "Pocket Mini Projector"],
    images: ["1507612344299-8ee2392898c2", "1591869754715-5f679687039c", "1515940175183-6798529cb860", "1756705533779-105bf34e0722", "1622086634181-3f944f83a49e"],
    basePrice: 79,
    description: "Reliable everyday technology with modern connectivity, practical performance, and manufacturer-backed warranty.",
    specs: [["Warranty", ["1 year", "2 years"]], ["Connectivity", ["Wi-Fi + Bluetooth", "USB-C"]], ["Color", ["Graphite", "Silver", "Blue"]]],
  },
  {
    category: "Home & Kitchen",
    shortName: "Home",
    brands: ["Hearth & Home", "Nestwell", "CookCraft", "Forma", "Casa"],
    names: ["Nordic Accent Chair", "Tri-Ply Cookware Set", "StackSmart Storage Boxes", "Rapid Boil Kettle", "Textured Ceramic Vase", "Solid Wood Side Table", "Nonstick Fry Pan Set", "Pantry Container Kit", "Compact Air Fryer", "Woven Cushion Pair", "Bamboo Shoe Rack", "Chef Knife Block", "Cotton Bedsheet Set", "Arc Floor Lamp", "Stoneware Dinner Set"],
    images: ["1549221497-62c16fb6d24f", "1741992557222-10a2bfb7f5ea", "1599672122041-26d7db7a5a06", "1556908289-5997a918fbe6", "1556910585-09baa3a3998e"],
    basePrice: 28,
    description: "Thoughtful essentials that make cooking, organizing, and relaxing at home feel easier.",
    specs: [["Material", ["Wood", "Steel", "Ceramic", "Cotton"]], ["Assembly", ["Ready to use", "Easy assembly"]], ["Warranty", ["6 months", "1 year"]]],
  },
  {
    category: "Beauty & Personal Care",
    shortName: "Beauty",
    brands: ["Lumière", "Aura", "Nue", "Mellow", "Botanica"],
    names: ["Cloud Dew Face Serum", "Velvet Matte Lip Color", "Repair Ritual Shampoo", "Dream Petal Eau de Parfum", "Mineral Daily Sunscreen", "Soft Focus Skin Tint", "Barrier Restore Cream", "Volume Lift Conditioner", "Rosewater Face Mist", "Precision Kajal Pencil", "Vitamin C Cleanser", "Midnight Musk Perfume", "Scalp Balance Oil", "Glow Powder Blush", "Hydrating Body Lotion"],
    images: ["1773305676182-5f34519e11b6", "1718068838055-3a8311f0e8ba", "1589903365355-a2bf5999d296", "1667769462514-1fd738b38498", "1598440947619-2c35fc9aa908"],
    basePrice: 14,
    description: "A carefully selected personal-care essential made for comfortable, everyday routines.",
    specs: [["Size", ["30 ml", "50 ml", "100 ml"]], ["Use", ["Daily", "As needed"]], ["Type", ["All skin types", "All hair types"]]],
  },
  {
    category: "Footwear",
    shortName: "Footwear",
    brands: ["Stride", "AeroStep", "Cobbler Co.", "Sole Story", "Runway"],
    names: ["CloudRun Everyday Sneakers", "Braided Comfort Sandals", "Block Heel Pumps", "Classic Oxford Formal Shoes", "Cushioned Home Slippers", "Retro Court Sneakers", "Leather Strap Sandals", "Pointed Kitten Heels", "Derby Office Shoes", "Soft Slide Slippers", "TrailGrip Running Shoes", "Platform Casual Sneakers", "Embellished Festive Sandals", "Suede Loafers", "Waterproof Hiking Shoes"],
    images: ["1657526883095-a7a5c463b94e", "1544601510-638cdd9ae736", "1661777997192-6b4efeefa0f2", "1648818283312-0ef710ca1aae", "1636262900147-fb56689b61c5"],
    basePrice: 32,
    description: "Supportive, versatile footwear with durable soles and all-day comfort.",
    specs: [["Upper", ["Knit", "Leather", "Synthetic"]], ["Sole", ["Rubber", "EVA cushion"]], ["Fit", ["True to size", "Relaxed"]]],
  },
  {
    category: "Bags & Accessories",
    shortName: "Bags",
    brands: ["Carry On", "Maison Rue", "Hide & Seek", "Tempo", "Sol"],
    names: ["Metro Laptop Backpack", "Sculpted Mini Handbag", "Slim Leather Wallet", "Classic Steel Watch", "Polarized Wayfarer Sunglasses", "Travel Weekender Bag", "Quilted Shoulder Bag", "RFID Card Wallet", "Minimal Mesh Watch", "Round Gradient Sunglasses", "Rolltop Daily Backpack", "Structured Work Tote", "Canvas Zip Pouch", "Chronograph Sport Watch", "Cat-Eye Sunglasses"],
    images: ["1511556820780-d912e42b4980", "1616876313400-7a88a027ada8", "1575429885190-43af8fc0c1cf", "1677773239708-51db0e45ac3b", "1507612344299-8ee2392898c2"],
    basePrice: 18,
    description: "A polished everyday accessory with practical storage and dependable materials.",
    specs: [["Material", ["Canvas", "Vegan leather", "Stainless steel"]], ["Closure", ["Zip", "Magnetic", "Buckle"]], ["Warranty", ["6 months", "1 year"]]],
  },
  {
    category: "Grocery & Food",
    shortName: "Grocery",
    brands: ["Daily Basket", "Harvest", "Good Grain", "Fresh Sip", "HomeCare"],
    names: ["Sea Salt Trail Mix", "Cold Brew Coffee Pack", "Whole Grain Pasta", "Sparkling Fruit Beverage", "Basmati Rice 5 kg", "Dark Chocolate Bites", "Masala Tea Bags", "Crunchy Peanut Butter", "Olive Oil 1 L", "Breakfast Oats", "Dishwash Liquid Refill", "Laundry Detergent Pack", "Roasted Almonds", "Tomato Basil Sauce", "Coconut Water Pack"],
    images: ["1738618141224-815f18b8e469", "1577374559203-09a9f2368bf3", "1542838132-92c53300491e", "1606787366850-de6330128bfc", "1547592180-85f173990554"],
    basePrice: 5,
    description: "A pantry or household staple selected for dependable quality and everyday value.",
    specs: [["Pack", ["Single", "Pack of 3", "Family pack"]], ["Shelf life", ["6 months", "12 months"]], ["Storage", ["Cool and dry", "Refrigerate after opening"]]],
  },
  {
    category: "Books & Stationery",
    shortName: "Books",
    brands: ["PageTurner", "Scholar", "Paper & Ink", "Studio Line", "Writewell"],
    names: ["The Midnight Library Novel", "Modern Physics Textbook", "Hardbound Daily Notebook", "Smooth Gel Pen Set", "Watercolor Art Kit", "World History Atlas", "Beginner Coding Handbook", "Dotted Journal Planner", "Fine Liner Pen Pack", "Acrylic Paint Set", "Classic Mystery Collection", "School Geometry Box", "Recycled Sketchbook", "Brush Marker Set", "Desk Organizer Caddy"],
    images: ["1588786606871-85ba6414a1ea", "1776002394632-6246360b41de", "1495446815901-a7297e633e8d", "1455390582262-044cdead277a", "1517841905240-472988babdf9"],
    basePrice: 8,
    description: "Made for focused study, creative projects, and the pleasure of a good reading session.",
    specs: [["Format", ["Paperback", "Hardcover", "Box set"]], ["Language", ["English", "Bilingual"]], ["Age", ["12+", "All ages"]]],
  },
  {
    category: "Sports & Fitness",
    shortName: "Sports",
    brands: ["Motion", "CoreFlex", "Peak", "Arena", "ActiveLab"],
    names: ["DryFit Training T-Shirt", "GripPro Yoga Mat", "Hex Dumbbell Pair", "Resistance Band Set", "Stainless Sports Bottle", "Quick-Dry Running Shorts", "Foam Roller", "Adjustable Skipping Rope", "Training Gloves", "Core Balance Ball", "Badminton Racquet Set", "Football Size 5", "Cycling Helmet", "Gym Duffel Bag", "Ankle Weight Pair"],
    images: ["1517836357463-d25dfeac3438", "1599058917212-d750089bc07e", "1534438327276-14e5300c3a48", "1571019613454-1cb2f99b2d8b", "1518611012118-696072aa579a"],
    basePrice: 16,
    description: "Purpose-built training gear for comfortable movement, home workouts, and active days.",
    specs: [["Level", ["Beginner", "All levels"]], ["Material", ["Rubber", "Polyester", "Steel"]], ["Use", ["Indoor", "Indoor / outdoor"]]],
  },
  {
    category: "Toys & Baby Products",
    shortName: "Toys",
    brands: ["Tiny Joy", "PlayWorks", "Little Nest", "Bright Minds", "BabyDay"],
    names: ["Wooden Building Blocks", "Plush Musical Elephant", "Baby Cotton Romper Set", "Silicone Feeding Bowl", "Family Board Game", "Pull-Back Car Set", "Shape Sorting Cube", "Soft Activity Mat", "Stacking Ring Toy", "Leakproof Sippy Cup", "Magnetic Tile Set", "Newborn Swaddle Pair", "Pretend Kitchen Set", "Baby Bib Pack", "Junior Puzzle Collection"],
    images: ["1741389544696-0750a7ac6bbb", "1624233816617-86eefcfc82e6", "1589737172779-748786ed5ad8", "1545558014-8692077e9b5c", "1617547921567-505842756c60"],
    basePrice: 12,
    description: "A parent-friendly pick designed for safe play, learning, feeding, or everyday baby care.",
    specs: [["Age", ["0–12 months", "3+ years", "6+ years"]], ["Material", ["BPA-free", "Cotton", "Wood"]], ["Safety", ["Tested", "Child-safe finish"]]],
  },
  {
    category: "Automotive",
    shortName: "Auto",
    brands: ["DriveMate", "MotoPro", "CleanRide", "RoadSafe", "AutoEase"],
    names: ["Magnetic Car Phone Mount", "Bike Tank Storage Bag", "Car Wash Cleaning Kit", "Portable Tyre Inflator", "Memory Foam Seat Cushion", "Microfiber Cleaning Cloths", "Blind Spot Mirror Pair", "Bike Mobile Holder", "Car Vacuum Cleaner", "Dashboard Polish Spray", "Emergency Tool Kit", "Waterproof Bike Cover", "Car Boot Organizer", "Digital Tyre Gauge", "Universal Steering Cover"],
    images: ["1503736334956-4c8f8e92946d", "1489824904134-891ab64532f1", "1492144534655-ae79c964c9d7", "1590468266367-03b990fee82e", "1712230276780-f499a55e5bcf"],
    basePrice: 11,
    description: "A practical driving or riding accessory designed for convenience, care, and safer travel.",
    specs: [["Compatibility", ["Universal", "Most cars", "Most bikes"]], ["Power", ["Manual", "12V socket"]], ["Warranty", ["6 months", "1 year"]]],
  },
  {
    category: "Appliances",
    shortName: "Appliances",
    brands: ["AeroHome", "Mixwell", "PressPro", "CoolSpace", "WashMate"],
    names: ["SilentBreeze Table Fan", "PowerBlend Mixer Grinder", "SteamGlide Iron", "Front Load Washing Machine", "FrostFree Refrigerator", "Tower Fan with Remote", "Compact Food Processor", "Ceramic Dry Iron", "Top Load Washing Machine", "Double Door Refrigerator", "Solo Microwave Oven", "Instant Water Heater", "Robot Vacuum Cleaner", "Room Air Purifier", "Induction Cooktop"],
    images: ["1740803292374-1b167c1558b1", "1740803292814-13d2e35924c3", "1783700776216-cf661c778151", "1740803292822-a742c6a4fef0", "1745426431516-7fcf72dc6415"],
    basePrice: 39,
    description: "An efficient home appliance with straightforward controls and dependable everyday performance.",
    specs: [["Warranty", ["1 year", "2 years"]], ["Energy", ["Efficient", "4-star rated"]], ["Installation", ["Plug and play", "Assisted"]]],
  },
  {
    category: "Gaming",
    shortName: "Gaming",
    brands: ["PixelForge", "HyperPlay", "Nexus", "ArcadeLab", "Respawn"],
    names: ["Pro Wireless Controller", "RGB Mechanical Keyboard", "Precision Gaming Mouse", "NextBox Game Console", "Surround Gaming Headset", "Extended Desk Mousepad", "Controller Charging Dock", "Mini Retro Console", "Streaming Microphone", "Racing Wheel Set", "Portable Gaming Monitor", "Mobile Game Controller", "RGB Headphone Stand", "Console Carry Case", "Ergonomic Gaming Chair"],
    images: ["1542751371-adc38448a05e", "1593305841991-05c297ba4575", "1606144042614-b2417e99c4e3", "1732896065182-ad7d8fdc766f", "1621260372709-37a178f6952f"],
    basePrice: 24,
    description: "Responsive gaming gear designed for comfortable sessions and reliable cross-device play.",
    specs: [["Connection", ["Wireless", "USB-C", "Bluetooth"]], ["Compatibility", ["PC / console", "Multi-platform"]], ["Warranty", ["1 year", "2 years"]]],
  },
  {
    category: "Pet Supplies",
    shortName: "Pets",
    brands: ["Happy Paws", "Pet Pantry", "Wag & Whisker", "FurCare", "PawPlay"],
    names: ["Adult Dog Food 3 kg", "Interactive Treat Ball", "Gentle Pet Shampoo", "Adjustable Walking Harness", "Indoor Cat Food 2 kg", "Feather Wand Cat Toy", "Deshedding Grooming Brush", "Reflective Dog Collar", "Dental Chew Pack", "Washable Pet Bed", "Stainless Feeding Bowls", "Clumping Cat Litter", "Rope Tug Toy", "Portable Water Bottle", "Soft Pet Carrier"],
    images: ["1576534959896-38644a6af593", "1552053831-71594a27632d", "1583337130417-3346a1be7dee", "1548199973-03cce0bbc87b", "1450778869180-41d0601e046e"],
    basePrice: 9,
    description: "An everyday pet essential chosen for comfort, enrichment, grooming, or balanced care.",
    specs: [["Pet", ["Dog", "Cat", "Small pets"]], ["Size", ["Small", "Medium", "Large"]], ["Care", ["Washable", "Easy clean"]]],
  },
];

export const categoryMeta = seeds.map((seed, index) => ({
  name: seed.category,
  shortName: seed.shortName,
  image: image(seed.images[0]),
  count: seed.names.length,
  index,
}));

export const products: Product[] = seeds.flatMap((seed, categoryIndex) =>
  seed.names.map((name, productIndex) => {
    const price = Math.round((seed.basePrice + productIndex * (seed.basePrice > 50 ? 23 : seed.basePrice > 25 ? 9 : 4.5)) * 100) / 100;
    const subcategory = name.split(" ").slice(-2).join(" ");
    return {
      id: categoryIndex * 100 + productIndex + 1,
      name,
      brand: seed.brands[productIndex % seed.brands.length],
      price,
      oldPrice: productIndex % 3 === 0 ? Math.round(price * 1.22 * 100) / 100 : undefined,
      rating: Math.round((4.1 + ((productIndex * 7 + categoryIndex) % 9) / 10) * 10) / 10,
      category: seed.category,
      subcategory,
      image: image(seed.images[productIndex % seed.images.length]),
      badge: productIndex % 5 === 0 ? "Bestseller" : productIndex % 5 === 1 ? "New" : productIndex % 5 === 3 ? "Deal" : undefined,
      description: seed.description,
      stock: 4 + ((productIndex * 11 + categoryIndex * 3) % 43),
      specs: Object.fromEntries(seed.specs.map(([key, values], specIndex) => [key, values[(productIndex + specIndex) % values.length]])),
    };
  }),
);

export const featuredProducts = [
  products.find((p) => p.category === "Electronics"),
  products.find((p) => p.category === "Fashion & Clothing"),
  products.find((p) => p.category === "Home & Kitchen"),
  products.find((p) => p.category === "Footwear"),
  products.find((p) => p.category === "Grocery & Food"),
  products.find((p) => p.category === "Gaming"),
].filter((product): product is Product => Boolean(product));
